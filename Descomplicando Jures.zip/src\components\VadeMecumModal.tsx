import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, X, Copy, Check, Scale } from 'lucide-react';
import { QUICK_ARTICLES } from '../data/vadeMecumData';
import type { QuickArticle } from '../types';

interface VadeMecumModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VadeMecumModal: React.FC<VadeMecumModalProps> = ({
  isOpen,
  onClose
}) => {
  const [search, setSearch] = useState('');
  const [selectedLaw, setSelectedLaw] = useState<string>('Todas');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const laws = ['Todas', 'CF/88', 'CC/02', 'CP/40', 'CPC/15', 'CTN/66'];

  // Handle ESC key to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const filteredArticles = useMemo(() => {
    return QUICK_ARTICLES.filter((art) => {
      if (selectedLaw !== 'Todas' && art.code !== selectedLaw) {
        return false;
      }
      if (!search.trim()) return true;
      const q = search.toLowerCase();
      return (
        art.article.toLowerCase().includes(q) ||
        art.summary.toLowerCase().includes(q) ||
        art.fullText.toLowerCase().includes(q) ||
        art.category.toLowerCase().includes(q) ||
        art.law.toLowerCase().includes(q)
      );
    });
  }, [search, selectedLaw]);

  const handleCopy = (art: QuickArticle) => {
    navigator.clipboard.writeText(`${art.code} - ${art.article}: ${art.fullText}`);
    setCopiedId(art.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-y-auto bg-black/50 backdrop-blur-md flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative z-10 w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-black/[0.08] flex flex-col max-h-[85vh] overflow-hidden"
        >
          {/* Header & Search */}
          <div className="p-5 border-b border-neutral-100 bg-neutral-50/70">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-[#1A1A1A] text-white flex items-center justify-center">
                  <Scale className="w-4 h-4 text-purple-300" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-[#1A1A1A]">Consulta Express Vade Mecum</h3>
                  <p className="text-[11px] text-neutral-500">Busca instantânea de artigos de lei seca fundamentais</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 rounded-full hover:bg-neutral-200 text-neutral-500 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Input */}
            <div className="relative">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                autoFocus
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Digite o número do artigo ou tema (ex: Artigo 5º, Dolo, Tutela)..."
                className="w-full pl-9 pr-8 py-2.5 rounded-2xl bg-white border border-neutral-200 text-xs text-neutral-800 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 transition-all"
              />
              {search && (
                <button
                  onClick={() => setSearch('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Filter pills */}
            <div className="flex items-center gap-1.5 mt-3 overflow-x-auto pb-1 scrollbar-none">
              {laws.map((law) => (
                <button
                  key={law}
                  onClick={() => setSelectedLaw(law)}
                  className={`px-3 py-1 rounded-full text-[11px] font-semibold whitespace-nowrap cursor-pointer transition-colors ${
                    selectedLaw === law
                      ? 'bg-[#1A1A1A] text-white'
                      : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-100'
                  }`}
                >
                  {law}
                </button>
              ))}
            </div>
          </div>

          {/* Results List */}
          <div className="p-5 overflow-y-auto space-y-3 flex-1">
            {filteredArticles.length > 0 ? (
              filteredArticles.map((art) => {
                const isCopied = copiedId === art.id;
                return (
                  <div
                    key={art.id}
                    className="p-4 rounded-2xl bg-white border border-neutral-200 hover:border-purple-300 transition-colors shadow-2xs"
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-purple-100 text-purple-800">
                          {art.code}
                        </span>
                        <span className="text-xs font-bold text-neutral-900">{art.article}</span>
                        <span className="text-[10px] text-neutral-400">• {art.category}</span>
                      </div>

                      <button
                        onClick={() => handleCopy(art)}
                        className="px-2 py-1 rounded-md text-[11px] font-semibold text-neutral-600 hover:text-purple-700 hover:bg-purple-50 flex items-center gap-1 transition-all cursor-pointer"
                      >
                        {isCopied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                        <span>{isCopied ? 'Copiado!' : 'Copiar Artigo'}</span>
                      </button>
                    </div>

                    <p className="text-xs text-neutral-600 leading-relaxed font-normal">
                      {art.summary}
                    </p>
                  </div>
                );
              })
            ) : (
              <div className="py-12 text-center text-neutral-400 text-xs">
                Nenhum artigo correspondente à sua busca.
              </div>
            )}
          </div>

          {/* Footer Info */}
          <div className="px-5 py-3 border-t border-neutral-100 bg-neutral-50/50 flex items-center justify-between text-[11px] text-neutral-400">
            <span>Pressione <kbd className="font-mono bg-white px-1.5 py-0.5 rounded border">ESC</kbd> para fechar</span>
            <span>{filteredArticles.length} artigos encontrados</span>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
