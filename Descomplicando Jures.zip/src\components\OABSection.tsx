import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Award, CheckCircle2, XCircle, Sparkles, Clock } from 'lucide-react';
import { OAB_QUESTION_PREVIEW, UPCOMING_OAB_SIMULATORS } from '../data/oabTeaserData';
import { triggerCompletionConfetti } from '../utils/confetti';

export const OABSection: React.FC = () => {
  const [selectedLetter, setSelectedLetter] = useState<'A' | 'B' | 'C' | 'D' | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);

  const q = OAB_QUESTION_PREVIEW;

  const handleSelectOption = (letter: 'A' | 'B' | 'C' | 'D') => {
    setSelectedLetter(letter);
    setShowExplanation(true);
    const chosen = q.options.find(o => o.letter === letter);
    if (chosen?.isCorrect) {
      triggerCompletionConfetti();
    }
  };

  const handleReset = () => {
    setSelectedLetter(null);
    setShowExplanation(false);
  };

  return (
    <section className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-8">
      {/* Top Status Header */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-50 border border-amber-200/80 text-amber-800 text-xs font-bold mb-4 shadow-2xs"
        >
          <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
          <span>Banco de Questões em Andamento • Banco Personalizado</span>
        </motion.div>

        <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-[#1A1A1A] leading-tight">
          Simulador de Questões{' '}
          <span className="bg-gradient-to-r from-purple-600 to-indigo-600 bg-clip-text text-transparent">
            OAB / FGV
          </span>
        </h1>
        <p className="mt-3 text-neutral-600 text-sm sm:text-base leading-relaxed">
          Área estruturada para a inserção das suas próprias perguntas e simulados comentados,
          com resolução passo a passo e índice de acertos por disciplina.
        </p>
      </div>

      {/* Interactive Question Preview Module */}
      <div className="max-w-3xl mx-auto mb-16">
        <div className="glass-panel rounded-3xl p-6 sm:p-8 border border-black/[0.08] shadow-xl bg-white/95">
          {/* Question Header */}
          <div className="flex flex-wrap items-center justify-between gap-2 pb-4 mb-5 border-b border-black/[0.06]">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold px-2.5 py-1 rounded-md bg-purple-100 text-purple-800 border border-purple-200">
                {q.exam}
              </span>
              <span className="text-xs font-semibold text-neutral-600">{q.subject}</span>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-[11px] font-medium text-neutral-400">Dificuldade: {q.difficulty}</span>
              {selectedLetter && (
                <button
                  onClick={handleReset}
                  className="text-xs font-semibold text-purple-700 hover:underline cursor-pointer"
                >
                  Tentar Novamente
                </button>
              )}
            </div>
          </div>

          {/* Statement */}
          <div className="mb-6">
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-2">Enunciado da Questão:</h3>
            <p className="text-sm sm:text-base text-neutral-900 leading-relaxed font-medium">
              {q.statement}
            </p>
          </div>

          {/* Alternatives A, B, C, D */}
          <div className="space-y-3 mb-6">
            {q.options.map((opt) => {
              const isSelected = selectedLetter === opt.letter;
              let optionStyle = 'bg-white border-neutral-200 hover:border-purple-300 hover:bg-neutral-50/70 text-neutral-800';

              if (selectedLetter !== null) {
                if (opt.isCorrect) {
                  optionStyle = 'bg-emerald-50 border-emerald-400 text-emerald-950 font-medium shadow-xs';
                } else if (isSelected && !opt.isCorrect) {
                  optionStyle = 'bg-rose-50 border-rose-300 text-rose-950';
                } else {
                  optionStyle = 'bg-neutral-50/60 border-neutral-200 opacity-60 text-neutral-600';
                }
              }

              return (
                <button
                  key={opt.letter}
                  disabled={selectedLetter !== null}
                  onClick={() => handleSelectOption(opt.letter)}
                  className={`w-full p-4 rounded-2xl border text-left text-xs sm:text-sm flex items-start gap-3 transition-all cursor-pointer ${optionStyle}`}
                >
                  <span className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs flex-shrink-0 mt-0.5 ${
                    selectedLetter !== null && opt.isCorrect
                      ? 'bg-emerald-600 text-white'
                      : isSelected && !opt.isCorrect
                      ? 'bg-rose-600 text-white'
                      : 'bg-neutral-100 text-neutral-700'
                  }`}>
                    {opt.letter}
                  </span>
                  <div className="flex-1 leading-relaxed">
                    <span>{opt.text}</span>
                  </div>

                  {selectedLetter !== null && (
                    <div className="flex-shrink-0 ml-2">
                      {opt.isCorrect ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                      ) : isSelected ? (
                        <XCircle className="w-5 h-5 text-rose-600" />
                      ) : null}
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          {/* Detailed Explanation Drawer */}
          <AnimatePresence>
            {showExplanation && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="p-5 rounded-2xl bg-neutral-50 border border-neutral-200/80"
              >
                <div className="flex items-center gap-2 mb-2 text-xs font-bold text-neutral-800">
                  <Sparkles className="w-4 h-4 text-purple-600" />
                  <span>Comentário & Gabarito Oficial FGV:</span>
                </div>
                <p className="text-xs sm:text-sm text-neutral-700 leading-relaxed mb-3">
                  {q.options.find(o => o.isCorrect)?.explanation}
                </p>
                <div className="text-[11px] text-purple-800 font-semibold bg-purple-50 p-2.5 rounded-xl border border-purple-200/60">
                  📖 Fundamentação Legal: {q.legalBasis}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Upcoming Simulators Grid */}
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold text-[#1A1A1A]">Simulados e Provas Programadas</h2>
            <p className="text-xs text-neutral-500">Módulos que estarão ativos conforme você adicionar seu banco de questões</p>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-neutral-100 text-neutral-600">
            {UPCOMING_OAB_SIMULATORS.length} Modos Planejados
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {UPCOMING_OAB_SIMULATORS.map((sim) => (
            <div
              key={sim.examName}
              className="glass-panel rounded-2xl p-5 border border-black/[0.06] flex flex-col justify-between glow-card-hover"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-purple-50 text-purple-700 border border-purple-200">
                    {sim.badge}
                  </span>
                  <span className="text-xs text-neutral-400 font-medium">
                    {sim.questionsCount} questões
                  </span>
                </div>
                <h3 className="font-bold text-base text-[#1A1A1A]">{sim.examName}</h3>
                <div className="mt-1 flex items-center gap-2 text-xs text-neutral-500">
                  <Clock className="w-3.5 h-3.5 text-neutral-400" />
                  <span>Duração estimada: {sim.timeMinutes} min</span>
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-black/[0.04] flex items-center justify-between">
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                  {sim.status}
                </span>

                <span className="text-xs text-neutral-400 font-medium">
                  Aguardando questões
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Developer Customization Banner */}
        <div className="mt-8 p-6 rounded-3xl bg-neutral-100/70 border border-neutral-200 text-neutral-700">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-full bg-[#1A1A1A] text-white flex items-center justify-center flex-shrink-0 mt-0.5">
              <Award className="w-4 h-4 text-purple-300" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-[#1A1A1A]">Pronto para Receber Suas Questões</h4>
              <p className="mt-1 text-xs text-neutral-600 leading-relaxed">
                Quando você quiser carregar suas próprias perguntas com as alternativas (A, B, C, D) e explicações, basta me enviar ou colar no arquivo <code>src/data/oabTeaserData.ts</code>. A lógica de correção interativa, cronômetro e feedback já está 100% pronta e modularizada!
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
