import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, CheckCircle2, Clock, Sparkles, TrendingUp, Award } from 'lucide-react';

interface HeroBentoProps {
  completedCount: number;
  totalTopicsCount: number;
  onExploreClick: () => void;
  onOpenOABTeaser: () => void;
}

export const HeroBento: React.FC<HeroBentoProps> = ({
  completedCount,
  totalTopicsCount,
  onExploreClick,
  onOpenOABTeaser
}) => {
  const completionPercentage = Math.round((completedCount / (totalTopicsCount || 1)) * 100);

  // SVG circle calculation
  const radius = 38;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (completionPercentage / 100) * circumference;

  return (
    <section className="relative w-full max-w-7xl mx-auto px-4 sm:px-6 pt-6 pb-10">
      {/* Ambient iridescent glow background */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[350px] bg-gradient-to-tr from-purple-200/40 via-pink-100/30 to-indigo-100/30 blur-3xl -z-10 rounded-full pointer-events-none" />

      {/* Top Banner / Announcement Pill */}
      <div className="flex justify-center mb-6">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
          onClick={onOpenOABTeaser}
          className="group inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/80 hover:bg-white text-xs font-medium text-neutral-700 border border-black/[0.06] shadow-xs cursor-pointer transition-all hover:border-purple-300"
        >
          <span className="w-2 h-2 rounded-full bg-purple-600 animate-pulse" />
          <span className="text-neutral-500">Novo Módulo:</span>
          <span className="font-semibold text-neutral-900">Preparação Estruturada OAB & Faculdade</span>
          <ArrowRight className="w-3.5 h-3.5 text-neutral-400 group-hover:translate-x-0.5 transition-transform" />
        </motion.div>
      </div>

      {/* Main Hero Header */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <motion.h1
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#1A1A1A] leading-[1.12]"
        >
          O Direito explicado de forma{' '}
          <span className="relative inline-block">
            <span className="bg-gradient-to-r from-purple-600 via-indigo-600 to-pink-600 bg-clip-text text-transparent">
              simples e visual.
            </span>
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mt-4 text-base sm:text-lg text-neutral-600 font-normal max-w-2xl mx-auto leading-relaxed"
        >
          Sua central definitiva de estudos da faculdade de direito. Doutrina sintetizada,
          lei seca destacada e jurisprudência dos tribunais superiores sem prolixidade.
        </motion.p>
      </div>

      {/* Bento Grid Architecture */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        {/* Card 1: Student Progress & Ring (5 cols) */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.25 }}
          className="md:col-span-5 glass-panel rounded-3xl p-6 sm:p-7 flex flex-col justify-between glow-card-hover relative overflow-hidden"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping opacity-75" />
              <span className="text-xs font-semibold uppercase tracking-wider text-neutral-500">Seu Progresso Semestral</span>
            </div>
            <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
              {completedCount} de {totalTopicsCount} concluídos
            </span>
          </div>

          <div className="flex items-center gap-6 my-2">
            {/* Circular Progress Meter */}
            <div className="relative w-24 h-24 flex-shrink-0 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r={radius}
                  className="stroke-neutral-200/80"
                  strokeWidth="8"
                  fill="transparent"
                />
                <circle
                  cx="50"
                  cy="50"
                  r={radius}
                  stroke="url(#purpleGradient)"
                  strokeWidth="8"
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  fill="transparent"
                  className="transition-all duration-700 ease-out"
                />
                <defs>
                  <linearGradient id="purpleGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#8B5CF6" />
                    <stop offset="100%" stopColor="#EC4899" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-xl font-bold tracking-tight text-[#1A1A1A]">{completionPercentage}%</span>
                <span className="text-[10px] text-neutral-500 font-medium">concluído</span>
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <h3 className="font-bold text-base text-[#1A1A1A]">Plano Universitário Ativo</h3>
              <p className="text-xs text-neutral-500 leading-snug">
                Mantenha a frequência para fixar as súmulas e prazos essenciais para suas provas.
              </p>
              <div className="flex items-center gap-3 mt-1 text-[11px] font-medium text-neutral-600">
                <span className="flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5 text-purple-600" /> +18% esta semana
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-neutral-400" /> ~14h de estudo
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-black/[0.04] flex items-center justify-between">
            <span className="text-xs text-neutral-500">Próxima meta recomendada:</span>
            <button
              onClick={onExploreClick}
              className="text-xs font-semibold text-purple-700 hover:text-purple-900 flex items-center gap-1 cursor-pointer"
            >
              Continuar Leitura <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </motion.div>

        {/* Card 2: Core Metrics & Features Highlights (4 cols) */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.35 }}
          className="md:col-span-4 glass-panel rounded-3xl p-6 sm:p-7 flex flex-col justify-between glow-card-hover"
        >
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-semibold uppercase tracking-wider text-neutral-500">Destaques do Método</span>
              <span className="p-1.5 rounded-full bg-purple-50 text-purple-600">
                <Sparkles className="w-3.5 h-3.5" />
              </span>
            </div>

            <ul className="space-y-3">
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="text-xs font-bold text-[#1A1A1A]">Lei Seca Mastigada</h4>
                  <p className="text-[11px] text-neutral-500">Artigos grifados com comentários objetivos.</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="text-xs font-bold text-[#1A1A1A]">Súmulas Vinculantes STF/STJ</h4>
                  <p className="text-[11px] text-neutral-500">Teses de repercussão geral aplicadas aos temas.</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="text-xs font-bold text-[#1A1A1A]">Dicas Práticas OAB (FGV)</h4>
                  <p className="text-[11px] text-neutral-500">Pegadinhas clássicas da 1ª e 2ª Fase.</p>
                </div>
              </li>
            </ul>
          </div>

          <div className="mt-4 pt-3 border-t border-black/[0.04] flex items-center justify-between">
            <span className="text-[11px] text-neutral-500 font-medium">6 disciplinas estruturadas</span>
            <span className="text-[11px] font-bold text-neutral-800">100% Gratuito</span>
          </div>
        </motion.div>

        {/* Card 3: Quick Action / OAB Teaser Callout (3 cols) */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.45 }}
          className="md:col-span-3 rounded-3xl p-6 sm:p-7 bg-[#1A1A1A] text-white flex flex-col justify-between shadow-xl relative overflow-hidden group cursor-pointer"
          onClick={onOpenOABTeaser}
        >
          {/* Subtle gradient corner */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/20 rounded-full blur-2xl group-hover:bg-purple-500/30 transition-all" />

          <div>
            <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-white/10 text-[10px] font-semibold text-purple-300 border border-white/10 mb-4">
              <Award className="w-3 h-3" /> Em Andamento
            </div>

            <h3 className="text-xl font-bold tracking-tight text-white leading-tight">
              Treinador de Questões OAB
            </h3>
            <p className="mt-2 text-xs text-neutral-400 leading-relaxed">
              Em breve você poderá praticar questões comentadas da FGV com estatísticas de acertos por disciplina.
            </p>
          </div>

          <div className="mt-6 flex items-center justify-between pt-4 border-t border-white/10">
            <span className="text-xs text-purple-200 font-medium">Ver Prévia</span>
            <div className="w-7 h-7 rounded-full bg-white/10 flex items-center justify-center group-hover:translate-x-1 transition-transform">
              <ArrowRight className="w-3.5 h-3.5 text-white" />
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
