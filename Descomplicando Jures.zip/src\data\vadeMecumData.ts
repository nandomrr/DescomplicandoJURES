import type { QuickArticle } from '../types';

export const QUICK_ARTICLES: QuickArticle[] = [
  {
    id: 'va-1',
    code: 'CF/88',
    law: 'Constituição da República Federativa do Brasil',
    article: 'Artigo 5º',
    summary: 'Todos são iguais perante a lei, sem distinção de qualquer natureza, garantindo-se aos brasileiros e aos estrangeiros residentes no País a inviolabilidade do direito à vida, à liberdade, à igualdade, à segurança e à propriedade.',
    fullText: 'Art. 5º Todos são iguais perante a lei, sem distinção de qualquer natureza, garantindo-se aos brasileiros e aos estrangeiros residentes no País a inviolabilidade do direito à vida, à liberdade, à igualdade, à segurança e à propriedade...',
    category: 'Direitos Fundamentais'
  },
  {
    id: 'va-2',
    code: 'CF/88',
    law: 'Constituição Federal',
    article: 'Artigo 37',
    summary: 'A administração pública direta e indireta de qualquer dos Poderes da União, dos Estados, do Distrito Federal e dos Municípios obedecerá aos princípios de legalidade, impessoalidade, moralidade, publicidade e eficiência.',
    fullText: 'Art. 37. A administração pública direta e indireta obedecerá aos princípios de legalidade, impessoalidade, moralidade, publicidade e eficiência (LIMPE)...',
    category: 'Administração Pública'
  },
  {
    id: 'va-3',
    code: 'CC/02',
    law: 'Código Civil',
    article: 'Artigo 186',
    summary: 'Aquele que, por ação ou omissão voluntária, negligência ou imprudência, violar direito e causar dano a outrem, ainda que exclusivamente moral, comete ato ilícito.',
    fullText: 'Art. 186. Aquele que, por ação ou omissão voluntária, negligência ou imprudência, violar direito e causar dano a outrem, ainda que exclusivamente moral, comete ato ilícito.',
    category: 'Responsabilidade Civil'
  },
  {
    id: 'va-4',
    code: 'CP/40',
    law: 'Código Penal',
    article: 'Artigo 121',
    summary: 'Matar alguém: Pena - reclusão, de seis a vinte anos. Parágrafo 2º elenca as qualificadoras (hediondez).',
    fullText: 'Art. 121. Matar alguém: Pena - reclusão, de seis a vinte anos. § 1º Se o agente comete o crime impelido por motivo de relevante valor social ou moral... diminui-se a pena de um sexto a um terço.',
    category: 'Crimes Contra a Vida'
  },
  {
    id: 'va-5',
    code: 'CPC/15',
    law: 'Código de Processo Civil',
    article: 'Artigo 300',
    summary: 'A tutela de urgência será concedida quando houver elementos que evidenciem a probabilidade do direito e o perigo de dano ou o risco ao resultado útil do processo.',
    fullText: 'Art. 300. A tutela de urgência será concedida quando houver elementos que evidenciem a probabilidade do direito e o perigo de dano ou o risco ao resultado útil do processo.',
    category: 'Tutelas Provisórias'
  },
  {
    id: 'va-6',
    code: 'CTN/66',
    law: 'Código Tributário Nacional',
    article: 'Artigo 3º',
    summary: 'Tributo é toda prestação pecuniária compulsória, em moeda ou cujo valor nela se possa exprimir, que não constitua sanção de ato ilícito, instituída em lei e cobrada mediante atividade administrativa plenamente vinculada.',
    fullText: 'Art. 3º Tributo é toda prestação pecuniária compulsória, em moeda ou cujo valor nela se possa exprimir, que não constitua sanção de ato ilícito, instituída em lei e cobrada mediante atividade administrativa plenamente vinculada.',
    category: 'Conceito de Tributo'
  }
];
