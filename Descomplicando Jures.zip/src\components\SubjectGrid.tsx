import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, BookMarked, X } from 'lucide-react';
import type { Subject, Topic } from '../types';
import { SubjectCard } from './SubjectCard';

interface SubjectGridProps {
  subjects: Subject[];
  completedTopics: string[];
  bookmarkedTopics: string[];
  onSelectTopic: (subject: Subject, topic: Topic) => void;
}

export const SubjectGrid: React.FC<SubjectGridProps> = ({
  subjects,
  completedTopics,
  bookmarkedTopics,
  onSelectTopic
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('Todas');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [onlyBookmarks, setOnlyBookmarks] = useState<boolean>(false);

  const categories = ['Todas', 'Direito Público', 'Direito Privado', 'Direito Processual'];

  const filteredSubjects = useMemo(() => {
    return subjects
      .map(subject => {
        // Filter by category
        if (selectedCategory !== 'Todas' && subject.category !== selectedCategory) {
          return null;
        }

        // Filter topics by bookmarks if toggled
        let topics = subject.topics;
        if (onlyBookmarks) {
          topics = topics.filter(t => bookmarkedTopics.includes(t.id));
          if (topics.length === 0) return null;
        }

        // Filter by search query
        if (searchQuery.trim()) {
          const query = searchQuery.toLowerCase().trim();
          const matchesSubject = 
            subject.title.toLowerCase().includes(query) ||
            subject.description.toLowerCase().includes(query) ||
            subject.code.toLowerCase().includes(query);

          const matchedTopics = topics.filter(topic =>
            topic.title.toLowerCase().includes(query) ||
            topic.summary.toLowerCase().includes(query) ||
            topic.dryLawArticles.some(a => a.article.toLowerCase().includes(query) || a.text.toLowerCase().includes(query)) ||
            topic.jurisprudence.some(j => j.summary.toLowerCase().includes(query) || j.number.toLowerCase().includes(query))
          );

          if (!matchesSubject && matchedTopics.length === 0) {
            return null;
          }

          // Return subject with matched topics or full topics if subject matched
          return {
            ...subject,
            topics: matchedTopics.length > 0 ? matchedTopics : topics
          };
        }

        return {
          ...subject,
          topics
        };
      })
      .filter((s): s is Subject => s !== null);
  }, [subjects, selectedCategory, searchQuery, onlyBookmarks, bookmarkedTopics]);

  return (
    <section id="disciplinas-grid" className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Section Header & Filters */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-purple-700">Módulos Universitários</span>
            <span className="text-xs text-neutral-400">•</span>
            <span className="text-xs text-neutral-500 font-medium">Faculdade & OAB</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#1A1A1A] mt-1">
            Disciplinas do Curso de Direito
          </h2>
        </div>

        {/* Search bar & filter pills */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
          {/* Search Input */}
          <div className="relative flex-1 sm:w-64">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filtrar por artigo, tema ou lei..."
              className="w-full pl-9 pr-8 py-2 rounded-full bg-white border border-black/[0.08] text-xs text-neutral-800 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 transition-all shadow-2xs"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Bookmarks Toggle */}
          <button
            onClick={() => setOnlyBookmarks(!onlyBookmarks)}
            className={`px-3.5 py-2 rounded-full text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer border ${
              onlyBookmarks
                ? 'bg-amber-500 text-white border-amber-600 shadow-sm'
                : 'bg-white text-neutral-700 border-black/[0.08] hover:bg-neutral-50'
            }`}
          >
            <BookMarked className={`w-3.5 h-3.5 ${onlyBookmarks ? 'fill-white' : 'text-neutral-500'}`} />
            <span>Salvos ({bookmarkedTopics.length})</span>
          </button>
        </div>
      </div>

      {/* Category Pills Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 mb-6 scrollbar-none">
        {categories.map((cat) => {
          const isSelected = selectedCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all duration-200 cursor-pointer ${
                isSelected
                  ? 'bg-[#1A1A1A] text-white shadow-xs'
                  : 'bg-white/80 hover:bg-white text-neutral-600 border border-black/[0.06] hover:border-black/[0.12]'
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* Grid of Subjects */}
      {filteredSubjects.length > 0 ? (
        <motion.div
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          <AnimatePresence>
            {filteredSubjects.map((subject) => (
              <SubjectCard
                key={subject.id}
                subject={subject}
                completedTopics={completedTopics}
                bookmarkedTopics={bookmarkedTopics}
                onSelectTopic={onSelectTopic}
              />
            ))}
          </AnimatePresence>
        </motion.div>
      ) : (
        /* Empty State */
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="glass-panel rounded-3xl p-12 text-center max-w-md mx-auto my-8 border border-black/[0.06]"
        >
          <div className="w-12 h-12 rounded-full bg-purple-50 text-purple-600 flex items-center justify-center mx-auto mb-3">
            <Search className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-[#1A1A1A]">Nenhum conteúdo encontrado</h3>
          <p className="mt-1 text-xs text-neutral-500">
            Nenhuma disciplina ou artigo corresponde a &quot;{searchQuery}&quot;. Tente outros termos como &quot;Art. 5º&quot;, &quot;Homicídio&quot; ou &quot;Tutela&quot;.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('Todas');
              setOnlyBookmarks(false);
            }}
            className="mt-4 px-4 py-2 rounded-full bg-[#1A1A1A] text-white text-xs font-semibold hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            Limpar Filtros
          </button>
        </motion.div>
      )}
    </section>
  );
};
