# ⚖️ Descomplicando Jures

> **Painel Inteligente de Estudos Jurídicos Universitários & Preparação OAB**  
> Desenvolvido com base no Design System e módulos visuais do **Lifemed Web Motion**, com animações fluidas em **Motion**, layout responsivo para Computador e Celular, e arquitetura modular pronta para deploy direto na **Vercel**.

---

## 🚀 Como Subir no Vercel (Passo a Passo)

Este projeto foi construído **sem qualquer dependência de `localhost`**, 100% pronto para a nuvem.

### Opção 1: Via Vercel CLI (Mais Rápido)
1. Abra o terminal na pasta do projeto:
   ```bash
   cd "C:\Users\enzom\Downloads\Descomplicando Jures"
   ```
2. Instale a CLI da Vercel (se ainda não tiver):
   ```bash
   npm i -g vercel
   ```
3. Execute o comando de deploy:
   ```bash
   vercel --prod
   ```
   *Selecione as opções padrão sugeridas pela Vercel e o seu painel estará no ar em poucos segundos!*

### Opção 2: Via GitHub / GitLab / Bitbucket
1. Crie um repositório no seu GitHub e suba os arquivos desta pasta.
2. Acesse [vercel.com](https://vercel.com) e clique em **"Add New Project"**.
3. Importe o repositório. A Vercel detectará automaticamente o framework **Vite**, o comando `npm run build` e o diretório de saída `dist`.
4. Clique em **Deploy**.

---

## 📂 Arquitetura Modular & Como Adicionar Seus Conteúdos

Para facilitar qualquer alteração futura e permitir que você mesmo gerencie os conteúdos da faculdade, tudo foi separado de maneira limpa em arquivos tipados:

### 1. Adicionar ou Editar Conteúdos da Faculdade
- **Arquivo:** `src/data/subjectsData.ts`
- Cada disciplina possui:
  - `code`: Sigla (ex: `CF/88`, `CC/02`, `CP/40`)
  - `title`: Nome da matéria
  - `category`: `Direito Público`, `Direito Privado` ou `Direito Processual`
  - `topics`: Lista de aulas e resumos com:
    - `summary`: Resumo inicial objetivo
    - `detailedContent`: Parágrafos aprofundados da doutrina
    - `keyPoints`: Mnemônicos e pontos cruciais de prova
    - `dryLawArticles`: Artigos da lei seca com botão de cópia rápida
    - `jurisprudence`: Súmulas vinculantes do STF/STJ com relevância
    - `oabTip`: Dica de ouro de como a FGV costuma cobrar o tema

### 2. Inserir Seus Flashcards Quando Quiser Ativar
- **Arquivo:** `src/data/oabTeaserData.ts`
- Na constante `FLASHCARD_PREVIEW_SAMPLES`, basta adicionar novos cards com:
  - `front`: A pergunta ou caso prático
  - `back`: A resposta fundamentada na lei
  - `hint`: Dica de memorização

### 3. Inserir Suas Questões OAB com Gabarito
- **Arquivo:** `src/data/oabTeaserData.ts`
- Na constante `OAB_QUESTION_PREVIEW`, você pode cadastrar questões com:
  - `statement`: Enunciado da prova
  - `options`: Alternativas A, B, C e D (marcando `isCorrect: true` na correta)
  - `explanation`: Comentário da resolução oficial

### 4. Vade Mecum Express
- **Arquivo:** `src/data/vadeMecumData.ts`
- Contém artigos rápidos pesquisáveis por atalho de teclado (`Ctrl+K` ou `⌘K`).

---

## 🎨 Design System (Lifemed Web Motion)
- **Cores Principais:**
  - Carvão Primário: `#1A1A1A`
  - Fundo Neutro: `#F7F7F5`
  - Branco Puro: `#FFFFFF`
  - Gradiente Iridiscente: Violeta/Púrpura/Lavanda com mesh blur
  - Acentos de Status: Esmeralda `#10B981` (Concluído/Elegível), Âmbar `#F59E0B` (Em Andamento/Revisão)
- **Tipografia:** Plus Jakarta Sans & Newsreader (Editorial Legal)
- **Micro-interações:** Springs do `motion/react`, anel de progresso SVG, virada 3D de flashcards, confetes de celebração ao concluir tópicos e tocador simulado de áudio de foco acústico.

---

## 📱 100% Responsivo
- **Desktop:** Grid Bento multidimensional, drawer lateral de leitura, atalhos de teclado e barra superior flutuante.
- **Mobile:** Barra inferior de navegação ergonômica, gaveta de menu retrátil, áreas de toque de 44px+ e leitor imersivo em tela cheia.
