import React, { useState } from 'react';
import { motion } from 'motion/react';
import { RotateCw, Bell, Check, Clock, Brain, ArrowRight, Sparkles } from 'lucide-react';
import { FLASHCARD_PREVIEW_SAMPLES, UPCOMING_FLASHCARD_DECKS } from '../data/oabTeaserData';

interface FlashcardsSectionProps {
  notifiedDecks: string[];
  onToggleNotify: (deck: string) => void;
}

export const FlashcardsSection: React.FC<FlashcardsSectionProps> = ({
  notifiedDecks,
  onToggleNotify
}) => {
  const [isFlipped, setIsFlipped] = useState(false);
  const [currentSampleIndex, setCurrentSampleIndex] = useState(0);

  const sample = FLASHCARD_PREVIEW_SAMPLES[currentSampleIndex];

  const handleNextCard = () => {
    setIsFlipped(false);
    setCurrentSampleIndex((prev) => (prev + 1) % FLASHCARD_PREVIEW_SAMPLES.length);
  };

  const handleRating = (_rating: string) => {
    setTimeout(() => {
      handleNextCard();
    }, 400);
  };

  return (
    <section className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-8">
      {/* Top Status Header */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-50 border border-amber-200/80 text-amber-800 text-xs font-bold mb-4 shadow-2xs"
        >
          <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
          <span>Módulo em Andamento • Lançamento em Breve</span>
        </motion.div>

        <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-[#1A1A1A] leading-tight">
          Flashcards Jurídicos com{' '}
          <span className="bg-gradient-to-r from-purple-600 to-indigo-600 bg-clip-text text-transparent">
            Repetição Espaçada
          </span>
        </h1>
        <p className="mt-3 text-neutral-600 text-sm sm:text-base leading-relaxed">
          Estamos preparando baralhos inteligentes para você memorizar artigos da lei seca,
          prazos processuais e súmulas sem esforço e sem esquecimento.
        </p>
      </div>

      {/* Interactive 3D Preview Card Showcase */}
      <div className="max-w-xl mx-auto mb-16">
        <div className="flex items-center justify-between mb-3 px-2">
          <div className="flex items-center gap-2">
            <Brain className="w-4 h-4 text-purple-600" />
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-500">
              Demonstração Interativa ({currentSampleIndex + 1}/{FLASHCARD_PREVIEW_SAMPLES.length})
            </span>
          </div>
          <span className="text-xs font-semibold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-md">
            {sample.tag}
          </span>
        </div>

        {/* 3D Flip Card Container */}
        <div
          className="relative w-full h-80 sm:h-96 cursor-pointer perspective-1000 select-none"
          onClick={() => setIsFlipped(!isFlipped)}
        >
          <motion.div
            className="w-full h-full relative transform-style-3d transition-transform duration-500"
            animate={{ rotateY: isFlipped ? 180 : 0 }}
            transition={{ type: 'spring', stiffness: 260, damping: 20 }}
          >
            {/* FRONT OF CARD */}
            <div className="absolute inset-0 backface-hidden glass-panel rounded-3xl p-8 flex flex-col justify-between shadow-xl border border-black/[0.08] bg-white/95">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider">
                  Frente • {sample.deckName}
                </span>
                <span className="p-2 rounded-full bg-neutral-100 text-neutral-600 hover:bg-neutral-200 transition-colors">
                  <RotateCw className="w-3.5 h-3.5" />
                </span>
              </div>

              <div className="my-auto text-center">
                <span className="text-xs font-semibold text-purple-600 mb-2 block">{sample.subject}</span>
                <h3 className="text-xl sm:text-2xl font-bold text-[#1A1A1A] leading-snug">
                  {sample.front}
                </h3>
              </div>

              <div className="pt-4 border-t border-black/[0.04] text-center">
                <span className="text-xs text-neutral-400 font-medium flex items-center justify-center gap-1.5">
                  <RotateCw className="w-3 h-3 text-purple-500 animate-spin" />
                  Clique no card para virar e conferir a resposta
                </span>
              </div>
            </div>

            {/* BACK OF CARD */}
            <div className="absolute inset-0 backface-hidden rotate-y-180 rounded-3xl p-8 flex flex-col justify-between shadow-xl border border-purple-300 bg-gradient-to-br from-purple-900 to-[#1A1A1A] text-white">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-purple-300 uppercase tracking-wider">
                  Verso • Resposta Fundamentada
                </span>
                <span className="p-2 rounded-full bg-white/10 text-white">
                  <RotateCw className="w-3.5 h-3.5" />
                </span>
              </div>

              <div className="my-auto">
                <h4 className="text-sm font-bold text-purple-300 mb-2">Fundamentação Jurídica:</h4>
                <p className="text-sm sm:text-base text-neutral-100 leading-relaxed font-normal">
                  {sample.back}
                </p>
                {sample.hint && (
                  <div className="mt-3 p-2.5 rounded-xl bg-white/10 text-xs text-purple-200 border border-white/10">
                    💡 <strong>Dica de Memorização:</strong> {sample.hint}
                  </div>
                )}
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                <span className="text-xs text-neutral-400">Como você se saiu?</span>
                <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                  <button
                    onClick={() => handleRating('Difícil')}
                    className="px-3 py-1 rounded-full text-xs font-bold bg-rose-500/30 hover:bg-rose-500 text-rose-200 hover:text-white transition-all cursor-pointer"
                  >
                    Difícil
                  </button>
                  <button
                    onClick={() => handleRating('Bom')}
                    className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/30 hover:bg-amber-500 text-amber-200 hover:text-white transition-all cursor-pointer"
                  >
                    Bom
                  </button>
                  <button
                    onClick={() => handleRating('Fácil')}
                    className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/30 hover:bg-emerald-500 text-emerald-200 hover:text-white transition-all cursor-pointer"
                  >
                    Fácil
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Change Card Button */}
        <div className="flex justify-center mt-4">
          <button
            onClick={handleNextCard}
            className="px-4 py-1.5 rounded-full bg-white text-neutral-700 hover:bg-neutral-100 text-xs font-semibold border border-black/[0.08] shadow-xs flex items-center gap-1.5 cursor-pointer transition-all active:scale-95"
          >
            Próximo Card de Exemplo <ArrowRight className="w-3 h-3 text-neutral-400" />
          </button>
        </div>
      </div>

      {/* Upcoming Decks List */}
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold text-[#1A1A1A]">Baralhos em Desenvolvimento</h2>
            <p className="text-xs text-neutral-500">Decks categorizados por incidência de prova e semestre universitário</p>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-neutral-100 text-neutral-600">
            {UPCOMING_FLASHCARD_DECKS.length} Baralhos Mapeados
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {UPCOMING_FLASHCARD_DECKS.map((deck) => {
            const isNotified = notifiedDecks.includes(deck.title);
            return (
              <div
                key={deck.title}
                className="glass-panel rounded-2xl p-5 border border-black/[0.06] flex flex-col justify-between glow-card-hover"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-purple-50 text-purple-700 border border-purple-200">
                      {deck.discipline}
                    </span>
                    <span className="text-xs text-neutral-400 font-medium">
                      {deck.cardsCount} cards
                    </span>
                  </div>
                  <h3 className="font-bold text-base text-[#1A1A1A]">{deck.title}</h3>
                  <div className="mt-1 flex items-center gap-2 text-xs text-neutral-500">
                    <Clock className="w-3.5 h-3.5 text-neutral-400" />
                    <span>Nível: {deck.level}</span>
                  </div>
                </div>

                <div className="mt-5 pt-3 border-t border-black/[0.04] flex items-center justify-between">
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                    {deck.status}
                  </span>

                  <button
                    onClick={() => onToggleNotify(deck.title)}
                    className={`px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                      isNotified
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                        : 'bg-neutral-100 hover:bg-[#1A1A1A] hover:text-white text-neutral-700'
                    }`}
                  >
                    {isNotified ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-600" />
                        <span>Aviso Ativado</span>
                      </>
                    ) : (
                      <>
                        <Bell className="w-3 h-3 text-neutral-500" />
                        <span>Avise-me</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Developer / User Note Callout */}
        <div className="mt-8 p-6 rounded-3xl bg-neutral-100/70 border border-neutral-200 text-neutral-700">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-full bg-purple-600 text-white flex items-center justify-center flex-shrink-0 mt-0.5">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-[#1A1A1A]">Espaço Reservado para seus Próprios Flashcards</h4>
              <p className="mt-1 text-xs text-neutral-600 leading-relaxed">
                Esta aba foi totalmente modularizada e estilizada para que, quando você desejar inserir seus conteúdos de faculdade e baralhos no arquivo <code>src/data/oabTeaserData.ts</code>, a interface carregue instantaneamente os cards reais com virada 3D e contagem de acertos.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
