import React from 'react';
import { Scale, ShieldCheck } from 'lucide-react';
import type { NavigationTab } from '../types';

interface FooterProps {
  onTabChange: (tab: NavigationTab) => void;
  onOpenVadeMecum: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onTabChange,
  onOpenVadeMecum
}) => {
  return (
    <footer className="w-full border-t border-black/[0.06] bg-white/60 backdrop-blur-md mt-20 pt-12 pb-24 md:pb-12 text-neutral-600 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-10 border-b border-black/[0.04]">
          {/* Col 1: Brand & Mission */}
          <div className="md:col-span-5">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-full bg-[#1A1A1A] flex items-center justify-center text-white">
                <Scale className="w-4 h-4 text-purple-300" />
              </div>
              <span className="font-bold text-base text-[#1A1A1A]">
                Descomplicando <span className="bg-gradient-to-r from-purple-600 to-indigo-600 bg-clip-text text-transparent">Jures</span>
              </span>
            </div>
            <p className="text-neutral-500 leading-relaxed max-w-sm">
              Plataforma desenvolvida para simplificar os estudos da faculdade de direito e acelerar sua aprovação no Exame de Ordem com metodologia visual, resumos claros e memorização de alta performance.
            </p>
            <div className="mt-4 flex items-center gap-2 text-[11px] text-neutral-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Design System inspirado em Lifemed Web Motion</span>
            </div>
          </div>

          {/* Col 2: Disciplinas */}
          <div className="md:col-span-3">
            <h4 className="font-bold text-neutral-900 mb-3 text-xs uppercase tracking-wider">Módulos Universitários</h4>
            <ul className="space-y-2 text-neutral-500">
              <li><button onClick={() => onTabChange('conteudo')} className="hover:text-purple-600 cursor-pointer">Direito Constitucional</button></li>
              <li><button onClick={() => onTabChange('conteudo')} className="hover:text-purple-600 cursor-pointer">Direito Civil</button></li>
              <li><button onClick={() => onTabChange('conteudo')} className="hover:text-purple-600 cursor-pointer">Direito Penal</button></li>
              <li><button onClick={() => onTabChange('conteudo')} className="hover:text-purple-600 cursor-pointer">Direito Administrativo</button></li>
              <li><button onClick={() => onTabChange('conteudo')} className="hover:text-purple-600 cursor-pointer">Direito Tributário</button></li>
              <li><button onClick={() => onTabChange('conteudo')} className="hover:text-purple-600 cursor-pointer">Processo Civil</button></li>
            </ul>
          </div>

          {/* Col 3: Ferramentas & Vade Mecum */}
          <div className="md:col-span-4">
            <h4 className="font-bold text-neutral-900 mb-3 text-xs uppercase tracking-wider">Recursos de Estudo</h4>
            <ul className="space-y-2 text-neutral-500">
              <li>
                <button onClick={onOpenVadeMecum} className="hover:text-purple-600 flex items-center gap-1 cursor-pointer">
                  <span>Consulta Express Vade Mecum</span>
                </button>
              </li>
              <li>
                <button onClick={() => onTabChange('flashcards')} className="hover:text-purple-600 flex items-center gap-1.5 cursor-pointer">
                  <span>Flashcards Inteligentes</span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-purple-100 text-purple-700">Em Breve</span>
                </button>
              </li>
              <li>
                <button onClick={() => onTabChange('oab')} className="hover:text-purple-600 flex items-center gap-1.5 cursor-pointer">
                  <span>Simulador de Questões FGV</span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-purple-100 text-purple-700">Em Breve</span>
                </button>
              </li>
              <li>
                <button onClick={() => onTabChange('conteudo')} className="hover:text-purple-600 cursor-pointer">
                  Modo de Leitura Foco & Áudio
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-neutral-400 text-[11px]">
          <span>© {new Date().getFullYear()} Descomplicando Jures. Todos os direitos reservados.</span>
          <span className="flex items-center gap-1">
            Criado para estudantes de Direito & Candidatos OAB
          </span>
        </div>
      </div>
    </footer>
  );
};
