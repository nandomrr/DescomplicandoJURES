export type NavigationTab = 'conteudo' | 'flashcards' | 'oab' | 'vademecum';

export interface DryLawArticle {
  article: string;
  source: string;
  text: string;
  observation?: string;
}

export interface JurisprudenceItem {
  tribunal: 'STF' | 'STJ';
  number: string;
  summary: string;
  relevance: string;
}

export interface Topic {
  id: string;
  title: string;
  summary: string;
  detailedContent: string[];
  keyPoints: string[];
  dryLawArticles: DryLawArticle[];
  jurisprudence: JurisprudenceItem[];
  oabTip: string;
  readTime: string;
}

export interface Subject {
  id: string;
  code: string;
  title: string;
  category: 'Direito Público' | 'Direito Privado' | 'Direito Processual';
  description: string;
  iconName: string;
  totalArticles: number;
  estimatedHours: string;
  difficulty: 'Iniciante' | 'Intermediário' | 'Avançado';
  colorGradient: string;
  accentColor: string;
  topics: Topic[];
}

export interface FlashcardSample {
  id: string;
  subject: string;
  deckName: string;
  front: string;
  back: string;
  hint: string;
  tag: string;
}

export interface OABQuestionOption {
  letter: 'A' | 'B' | 'C' | 'D';
  text: string;
  isCorrect: boolean;
  explanation: string;
}

export interface OABQuestionPreview {
  id: string;
  exam: string;
  subject: string;
  difficulty: 'Fácil' | 'Média' | 'Difícil';
  statement: string;
  options: OABQuestionOption[];
  legalBasis: string;
}

export interface QuickArticle {
  id: string;
  code: string;
  law: string;
  article: string;
  summary: string;
  fullText: string;
  category: string;
}
