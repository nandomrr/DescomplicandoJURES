import type { Subject } from '../types';

export const SUBJECTS_DATA: Subject[] = [
  {
    id: 'direito-constitucional',
    code: 'CF/88',
    title: 'Direito Constitucional',
    category: 'Direito Público',
    description: 'Bases fundamentais do Estado Democrático de Direito, direitos humanos, remédios constitucionais e controle de constitucionalidade.',
    iconName: 'Scale',
    totalArticles: 250,
    estimatedHours: '28h de leitura',
    difficulty: 'Intermediário',
    colorGradient: 'from-purple-500/10 via-indigo-500/5 to-transparent',
    accentColor: '#8B5CF6',
    topics: [
      {
        id: 'const-direitos-fundamentais',
        title: 'Direitos e Garantias Individuais (Art. 5º)',
        summary: 'Análise aprofundada dos direitos individuais e coletivos, inviolabilidades, liberdades e suas limitações constitucionais.',
        detailedContent: [
          'O Art. 5º da CF/88 consagra o núcleo pétreo dos direitos fundamentais, aplicáveis a brasileiros e estrangeiros residentes ou em trânsito no país.',
          'Princípio da Igualdade (Isonomia): Material vs Formal. Tratar igualmente os iguais e desigualmente os desiguais na exata medida de suas desigualdades.',
          'Inviolabilidade de Domicílio (Art. 5º, XI): A casa é asilo inviolável. Exceções: flagrante delito, desastre, socorro, ou durante o dia por determinação judicial (RE 603.616 - STF exige fundadas razões prévias).',
          'Sigilo de Comunicações: Interceptação telefônica exige ordem judicial, para fins de investigação criminal ou instrução processual penal, nas hipóteses da Lei 9.296/96.'
        ],
        keyPoints: [
          'Eficácia horizontal dos direitos fundamentais nas relações privadas (STF)',
          'Núcleo pétreo implícito e explícito (Art. 60, § 4º, IV)',
          'Direitos absolutos não existem no ordenamento brasileiro (relatividade)'
        ],
        dryLawArticles: [
          {
            article: 'Art. 5º, XI, CF/88',
            source: 'Constituição Federal',
            text: 'A casa é asilo inviolável do indivíduo, ninguém nela podendo penetrar sem consentimento do morador, salvo em caso de flagrante delito ou desastre, ou para prestar socorro, ou, durante o dia, por determinação judicial.',
            observation: 'Atenção ao conceito amplo de domicílio (escritórios e quartos de hotel ocupados incluídos).'
          },
          {
            article: 'Art. 5º, LVI, CF/88',
            source: 'Constituição Federal',
            text: 'São inadmissíveis, no processo, as provas obtidas por meios ilícitos.',
            observation: 'Teoria dos Frutos da Árvore Envenenada (Fruits of the Poisonous Tree) com exceção da fonte independente.'
          }
        ],
        jurisprudence: [
          {
            tribunal: 'STF',
            number: 'Tema 280 (RE 603.616)',
            summary: 'A entrada forçada em domicílio sem mandado judicial só é lícita se amparada em fundadas razões, devidamente justificadas pelas circunstâncias do caso concreto.',
            relevance: 'Questão quase obrigatória na 1ª e 2ª Fase da OAB.'
          }
        ],
        oabTip: 'A FGV adora cobrar os horários da busca domiciliar: determinação judicial apenas durante o DIA (critério físico-astronômico ou horário das 06h às 18h conforme a Lei de Abuso de Autoridade).',
        readTime: '12 min'
      },
      {
        id: 'const-remedios',
        title: 'Remédios Constitucionais em Espécie',
        summary: 'Instrumentos processuais para tutela de direitos fundamentais: HC, MS, HD, MI e Ação Popular.',
        detailedContent: [
          'Habeas Corpus (Art. 5º, LXVIII): Tutela a liberdade de locomoção contra ilegalidade ou abuso de poder. É gratuito e não exige capacidade postulatória.',
          'Mandado de Segurança (Art. 5º, LXIX e LXX): Direito líquido e certo não amparado por HC ou HD. Prazo decadencial improrrogável de 120 dias.',
          'Habeas Data (Art. 5º, LXXII): Acesso e retificação de informações relativas à pessoa do impetrante em bancos de dados governamentais ou de caráter público. Exige recusa prévia na via administrativa (Súmula 2 STJ).',
          'Mandado de Injunção (Art. 5º, LXXI): Suprimento da falta de norma regulamentadora que torne inviável o exercício dos direitos e liberdades constitucionais.'
        ],
        keyPoints: [
          'HC e HD são ações gratuitas por determinação constitucional.',
          'Ação Popular: legitimidade ativa exclusiva de CIDADÃO no gozo dos direitos políticos.',
          'Súmula Vinculante 25: É ilícita a prisão civil de depositário infiel, qualquer que seja a modalidade do depósito.'
        ],
        dryLawArticles: [
          {
            article: 'Art. 5º, LXXIII, CF/88',
            source: 'Constituição Federal',
            text: 'Qualquer cidadão é parte legítima para propor ação popular que vise a anular ato lesivo ao patrimônio público ou de entidade de que o Estado participe, à moralidade administrativa, ao meio ambiente e ao patrimônio histórico e cultural...',
            observation: 'Cidadão = eleitor (com título eleitoral).'
          }
        ],
        jurisprudence: [
          {
            tribunal: 'STF',
            number: 'Súmula Vinculante 2',
            summary: 'É inconstitucional a lei ou ato normativo estadual ou distrital que disponha sobre sistemas de consórcios e sorteios, inclusive bingos e loterias.',
            relevance: 'Competência privativa da União.'
          }
        ],
        oabTip: 'Para o Mandado de Segurança, a prova DEVE ser pré-constituída. Não se admite dilação probatória ou testemunhas no processo!',
        readTime: '15 min'
      },
      {
        id: 'const-controle',
        title: 'Controle Concentrado vs Difuso de Constitucionalidade',
        summary: 'Mecanismos de fiscalização de conformidade das leis com a Constituição da República.',
        detailedContent: [
          'Controle Difuso (Concreto / Incidental): Qualquer juiz ou tribunal pode declarar a inconstitucionalidade. Efeito inter partes, retroativo (ex tunc), salvo modulação.',
          'Cláusula de Reserva de Plenário (Art. 97 CF): Tribunais só podem declarar a inconstitucionalidade pelo voto da maioria absoluta de seus membros ou do órgão especial (Súmula Vinculante 10).',
          'Controle Concentrado (Abstrato): Ajuizado perante o STF (ou TJ estadual para constituição estadual). Legitimados do Art. 103 da CF.',
          'Espécies: Ação Direta de Inconstitucionalidade (ADI), Ação Declaratória de Constitucionalidade (ADC), Ação Direta por Omissão (ADO) e Arguição de Descumprimento de Preceito Fundamental (ADPF).'
        ],
        keyPoints: [
          'Legitimados do Art. 103: 3 pessoas, 3 mesas, 3 entidades (universais vs especiais).',
          'ADPF tem caráter subsidiário: cabe quando não houver outro meio eficaz de sanar a lesividade.',
          'Efeito vinculante e erga omnes nas decisões de mérito em controle concentrado.'
        ],
        dryLawArticles: [
          {
            article: 'Art. 103, CF/88',
            source: 'Constituição Federal',
            text: 'Podem propor a ação direta de inconstitucionalidade e a ação declaratória de constitucionalidade: I - Presidente da República; II - Mesa do Senado; III - Mesa da Câmara; IV - Mesa da Assembleia; V - Governador; VI - PGR; VII - CFOAB; VIII - Partido com representação; IX - Confederação sindical ou entidade de classe de âmbito nacional.',
            observation: 'Governador, Mesa de AL e Confederações exigem pertinência temática.'
          }
        ],
        jurisprudence: [
          {
            tribunal: 'STF',
            number: 'Súmula Vinculante 10',
            summary: 'Viola a cláusula de reserva de plenário a decisão de órgão fracionário de tribunal que, embora não declare expressamente a inconstitucionalidade, afasta sua incidência no todo ou em parte.',
            relevance: 'Artigo 97 da CF - Vício formal insanável.'
          }
        ],
        oabTip: 'A OAB sempre pergunta a pertinência temática: Presidente, PGR, CFOAB e Mesas do Congresso NÃO precisam provar pertinência temática (são legitimados universais).',
        readTime: '18 min'
      }
    ]
  },
  {
    id: 'direito-civil',
    code: 'CC/02',
    title: 'Direito Civil',
    category: 'Direito Privado',
    description: 'Parte geral, pessoas, bens, fatos jurídicos, direito das obrigações, contratos, responsabilidade civil e direitos reais.',
    iconName: 'BookOpen',
    totalArticles: 2046,
    estimatedHours: '35h de leitura',
    difficulty: 'Intermediário',
    colorGradient: 'from-blue-500/10 via-cyan-500/5 to-transparent',
    accentColor: '#3B82F6',
    topics: [
      {
        id: 'civil-defeitos-negocio',
        title: 'Defeitos do Negócio Jurídico',
        summary: 'Vícios de consentimento (erro, dolo, coação, estado de perigo, lesão) e vício social (fraude contra credores).',
        detailedContent: [
          'O negócio jurídico perfeito pressupõe agente capaz, objeto lícito, possível e determinável, e forma prescrita ou não defesa em lei (Art. 104 CC).',
          'Erro ou Ignorância (Art. 138 CC): Falsa percepção da realidade. Deve ser substancial e escusável (cognoscível pela média das pessoas).',
          'Dolo (Art. 145 CC): Artifício malicioso empregado para induzir outrem em erro. Dolo principal gera anulação; dolo acidental apenas perdas e danos.',
          'Coação (Art. 151 CC): Violência moral ou psicológica capaz de incutir na vítima fundado receio de dano iminente e considerável à sua pessoa, família ou bens.',
          'Lesão (Art. 157 CC): Prejuízo resultante da desproporção manifesta entre as prestações gerada por premente necessidade ou inexperiência.',
          'Fraude contra Credores (Art. 158 CC): Prática de atos que diminuem o patrimônio do devedor insolvente em prejuízo dos credores quirografários. Anulação via Ação Pauliana.'
        ],
        keyPoints: [
          'Prazo decadencial de 4 anos para pleitear a anulação do negócio jurídico (Art. 178 CC).',
          'Simulação (Art. 167 CC) é caso de NULIDADE ABSOLUTA, não convalidando com o tempo.',
          'Estado de perigo exige conhecimento da outra parte sobre o dolo de aproveitamento.'
        ],
        dryLawArticles: [
          {
            article: 'Art. 178, CC/02',
            source: 'Código Civil',
            text: 'É de quatro anos o prazo de decadência para pleitear-se a anulação do negócio jurídico, contado: I - no caso de coação, do dia em que ela cessar; II - no de erro, dolo, fraude contra credores, estado de perigo ou lesão, do dia em que se realizou o negócio.',
            observation: 'Memorize o termo inicial da coação: do dia em que ela CESSAR!'
          }
        ],
        jurisprudence: [
          {
            tribunal: 'STJ',
            number: 'Súmula 375',
            summary: 'O reconhecimento da fraude à execução depende do registro da penhora do bem alienado ou da prova de má-fé do terceiro adquirente.',
            relevance: 'Diferença crucial entre Fraude contra Credores e Fraude à Execução.'
          }
        ],
        oabTip: 'Atenção máxima: Coação conta o prazo de 4 anos do dia em que ela CESSAR, e não da data do contrato!',
        readTime: '14 min'
      },
      {
        id: 'civil-responsabilidade',
        title: 'Responsabilidade Civil Subjetiva vs Objetiva',
        summary: 'Elementos do dever de indenizar: conduta ilícita, culpa, dano e nexo de causalidade.',
        detailedContent: [
          'Responsabilidade Subjetiva (Regra Geral - Art. 186 e 927 caput CC): Exige demonstração de culpa em sentido amplo (dolo ou negligência/imprudência/imperícia).',
          'Responsabilidade Objetiva (Exceção Legal - Art. 927 parágrafo único): Independe de culpa quando a lei determinar ou a atividade normal do autor implicar, por sua natureza, risco para os direitos de outrem (Teoria do Risco).',
          'Excludentes do Nexo Causal: Culpa exclusiva da vítima, fato de terceiro (com efeitos de força maior), e caso fortuito ou força maior externa.',
          'Dano Moral: Lesão a direitos da personalidade. Dano moral in re ipsa (presumido) não necessita de comprovação probatória (ex: inscrição indevida em cadastro de inadimplentes).'
        ],
        keyPoints: [
          'CDC adota responsabilidade objetiva do fornecedor pelo fato do produto ou serviço (Art. 12 e 14 CDC).',
          'Fortuito interno NÃO exclui a responsabilidade da instituição financeira (Súmula 479 STJ).',
          'Dano estético é cumulável com dano moral (Súmula 387 STJ).'
        ],
        dryLawArticles: [
          {
            article: 'Art. 927, Parágrafo Único, CC/02',
            source: 'Código Civil',
            text: 'Haverá obrigação de reparar o dano, independentemente de culpa, nos casos especificados em lei, ou quando a atividade normalmente desenvolvida pelo autor do dano implicar, por sua natureza, risco para os direitos de outrem.',
            observation: 'Cláusula geral de responsabilidade objetiva pelo risco da atividade.'
          }
        ],
        jurisprudence: [
          {
            tribunal: 'STJ',
            number: 'Súmula 479',
            summary: 'As instituições financeiras respondem objetivamente pelos danos gerados por fortuito interno relativo a fraudes e delitos praticados por terceiros no âmbito de operações bancárias.',
            relevance: 'Golpes do Pix, abertura de contas falsas, cartões clonados.'
          }
        ],
        oabTip: 'Súmula 387 do STJ cai com altíssima frequência: é lícita a cumulação das indenizações de dano estético e dano moral decorrentes do mesmo fato!',
        readTime: '16 min'
      }
    ]
  },
  {
    id: 'direito-penal',
    code: 'CP/40',
    title: 'Direito Penal',
    category: 'Direito Público',
    description: 'Teoria do delito, tipicidade, culpabilidade, concurso de pessoas, penas, dosimetria e crimes em espécie.',
    iconName: 'ShieldAlert',
    totalArticles: 361,
    estimatedHours: '30h de leitura',
    difficulty: 'Avançado',
    colorGradient: 'from-rose-500/10 via-red-500/5 to-transparent',
    accentColor: '#EF4444',
    topics: [
      {
        id: 'penal-teoria-crime',
        title: 'Teoria Tripartite do Crime',
        summary: 'Conceito analítico de crime: Fato Típico, Antijurídico (Ilícito) e Culpável.',
        detailedContent: [
          'Fato Típico: Composto por conduta (dolosa ou culposa, ação ou omissão), resultado naturalístico (nos crimes materiais), nexo causal e tipicidade (formal e conglobante/material).',
          'Princípio da Insignificância: Afasta a tipicidade MATERIAL da conduta. Requisitos do STF: mínima ofensividade da conduta, nenhuma periculosidade social da ação, reduzidíssimo grau de reprovabilidade do comportamento e inexpressividade da lesão jurídica provocada.',
          'Antijuridicidade (Ilicitude): Contradição entre a conduta e o ordenamento jurídico. Excluída pelas causas justificantes do Art. 23 do CP.',
          'Culpabilidade: Juízo de reprovação pessoal sobre o autor. Elementos: Imputabilidade penal, potencial consciência sobre a ilicitude e exigibilidade de conduta diversa.'
        ],
        keyPoints: [
          'Teoria Finalista da Ação (Hans Welzel): O dolo e a culpa migraram da culpabilidade para o fato típico.',
          'Coação moral irresistível afasta a culpabilidade (inexigibilidade de conduta diversa).',
          'Coação física irresistível afasta a conduta (fato atípico por ausência de vontade).'
        ],
        dryLawArticles: [
          {
            article: 'Art. 23, CP',
            source: 'Código Penal',
            text: 'Não há crime quando o agente pratica o fato: I - em estado de necessidade; II - em legítima defesa; III - em estrito cumprimento de dever legal ou no exercício regular de direito. Parágrafo único: O agente responderá pelo excesso doloso ou culposo.',
            observation: 'Causas excludentes da ilicitude gerais.'
          }
        ],
        jurisprudence: [
          {
            tribunal: 'STJ',
            number: 'Súmula 599',
            summary: 'O princípio da insignificância é inaplicável aos crimes contra a administração pública.',
            relevance: 'Prevalece a moralidade administrativa sobre o valor patrimonial.'
          }
        ],
        oabTip: 'Lembre-se da diferença clássica: Coação MORAL irresistível exclui a CULPABILIDADE; Coação FÍSICA (vis absoluta) exclui a CONDUTA, gerando atipicidade!',
        readTime: '20 min'
      },
      {
        id: 'penal-crimes-vida',
        title: 'Homicídio, Privilégio e Qualificadoras',
        summary: 'Artigo 121 do Código Penal, feminicídio, qualificadoras subjetivas e objetivas e perdão judicial.',
        detailedContent: [
          'Homicídio Simples (Art. 121, caput): Pena de 6 a 20 anos de reclusão.',
          'Homicídio Privilegiado (Art. 121, § 1º): Motivo de relevante valor social ou moral, ou sob o domínio de violenta emoção logo em seguida a injusta provocação da vítima. Causa de diminuição de pena obrigatória de 1/6 a 1/3.',
          'Homicídio Qualificado (Art. 121, § 2º): Pena de 12 a 30 anos. É crime hediondo (Lei 8.072/90).',
          'Qualificadoras Subjetivas: Motivo fútil, motivo torpe.',
          'Qualificadoras Objetivas: Emprego de veneno, fogo, asfixia, emboscada, traição, para assegurar execução ou impunidade de outro crime.',
          'Feminicídio (Art. 121, § 2º, VI): Homicídio contra a mulher por razões da condição de sexo feminino (violência doméstica/familiar ou menosprezo/discriminação). Qualificadora de natureza objetiva (STJ).'
        ],
        keyPoints: [
          'Compatibilidade entre Homicídio Privilegiado e Qualificado: Admite-se quando a qualificadora for de ordem OBJETIVA (ex: homicídio sob violenta emoção praticado por asfixia).',
          'Feminicídio e Motivo Torpe: STJ entende que NÃO há bis in idem na coexistência, pois feminicídio é qualificadora objetiva e motivo torpe é subjetiva.',
          'Perdão Judicial (Art. 121, § 5º): Apenas no homicídio culposo, quando as consequências da infração atingirem o próprio agente de forma tão grave que a pena se torne desnecessária.'
        ],
        dryLawArticles: [
          {
            article: 'Art. 121, § 2º-A, CP',
            source: 'Código Penal',
            text: 'Considera-se que há razões de condição de sexo feminino quando o crime envolve: I - violência doméstica e familiar; II - menosprezo ou discriminação à condição de mulher.',
            observation: 'Conceito legal de feminicídio.'
          }
        ],
        jurisprudence: [
          {
            tribunal: 'STJ',
            number: 'Tema Repetitivo 1.047',
            summary: 'As qualificadoras do motivo fútil e do feminicídio podem concorrer no mesmo fato criminoso, não havendo bis in idem, dada a natureza subjetiva da primeira e objetiva da segunda.',
            relevance: 'Decisão pacificadora da 3ª Seção do STJ.'
          }
        ],
        oabTip: 'O homicídio qualificado-privilegiado NÃO é considerado crime hediondo! O privilégio afasta a hediondez.',
        readTime: '17 min'
      }
    ]
  },
  {
    id: 'direito-administrativo',
    code: 'DA/21',
    title: 'Direito Administrativo',
    category: 'Direito Público',
    description: 'Princípios constitucionais, regime jurídico administrativo, atos, poderes, licitações (Lei 14.133/21) e agentes públicos.',
    iconName: 'Building2',
    totalArticles: 195,
    estimatedHours: '25h de leitura',
    difficulty: 'Intermediário',
    colorGradient: 'from-amber-500/10 via-orange-500/5 to-transparent',
    accentColor: '#F59E0B',
    topics: [
      {
        id: 'adm-principios-atos',
        title: 'Princípios Expressos e Teoria dos Atos Administrativos',
        summary: 'Artigo 37 da CF/88, atributos dos atos administrativos e regime de nulidades.',
        detailedContent: [
          'Princípios Expressos (LIMPE): Legalidade (só agir com permissão legal expressa), Impessoalidade (vedação à autopromoção, finalidade pública), Moralidade (probidade e boa-fé), Publicidade (transparência e eficácia) e Eficiência (busca por resultados ótimos).',
          'Requisitos / Elementos do Ato Administrativo (COMFIFORMOOB): Competência, Finalidade, Forma, Motivo e Objeto.',
          'Atributos dos Atos Administrativos (PATI): Presunção de legitimidade e veracidade, Autoexecutoriedade, Tipicidade e Imperatividade.',
          'Extinção dos Atos: Anulação (atos ilegais, efeito ex tunc - Súmula 473 STF) vs Revogação (atos legais e discricionários por razões de conveniência e oportunidade, efeito ex nunc).'
        ],
        keyPoints: [
          'Vícios em Competência e Forma (quando não essenciais) admitem CONVALIDAÇÃO (efeito ex tunc).',
          'Vícios em Motivo, Objeto e Finalidade são insanáveis, impondo anulação obrigatória.',
          'Súmula 473 do STF: Princípio da Autotutela Administrativa.'
        ],
        dryLawArticles: [
          {
            article: 'Art. 37, § 1º, CF/88',
            source: 'Constituição Federal',
            text: 'A publicidade dos atos, programas, obras, serviços e campanhas dos órgãos públicos deverá ter caráter educativo, informativo ou de orientação social, dela não podendo constar nomes, símbolos ou imagens que caracterizem promoção pessoal de autoridades ou servidores públicos.',
            observation: 'Expressão direta do princípio da impessoalidade.'
          }
        ],
        jurisprudence: [
          {
            tribunal: 'STF',
            number: 'Súmula Vinculante 13',
            summary: 'A nomeação de cônjuge, companheiro ou parente em linha reta, colateral ou por afinidade, até o terceiro grau, para cargo em comissão ou de confiança viola a Constituição Federal (Nepotismo).',
            relevance: 'Exceção reconhecida pelo STF: Cargos de natureza estritamente política (ex: Ministros e Secretários de Estado), ressalvada manifesta falta de qualificação técnica.'
          }
        ],
        oabTip: 'Revogação gera efeitos EX NUNC (para frente). Anulação gera efeitos EX TUNC (retroativos). O mnemônico clássico: Anulação dá um Tapa na nuca (retrocede); Revogação dá um empurrão para Frente (Nunca retrocede).',
        readTime: '15 min'
      },
      {
        id: 'adm-licitacoes-14133',
        title: 'Nova Lei de Licitações (Lei nº 14.133/2021)',
        summary: 'Modalidades de licitação, critérios de julgamento, dispensa e inexigibilidade.',
        detailedContent: [
          'A Lei nº 14.133/21 unificou o regime geral de licitações e contratos administrativos.',
          'Modalidades Licitatórias Vigentes: Pregão, Concorrência, Concurso, Leilão e Diálogo Competitivo. Tomada de Preços e Convite foram EXTINTOS!',
          'Diálogo Competitivo (Art. 32): Modalidade para contratação de obras, serviços e compras em que a Administração realiza diálogos com licitantes previamente selecionados para desenvolver alternativas técnicas.',
          'Inexigibilidade de Licitação (Art. 74): Inviabilidade de competição (rol exemplificativo). Ex: fornecedor exclusivo, profissional do setor artístico consagrado, serviços técnicos especializados com profissionais de notória especialização.',
          'Dispensa de Licitação (Art. 75): Competição viável, mas a lei autoriza não licitar (rol taxativo). Ex: baixo valor, emergência, licitação deserta ou fracassada.'
        ],
        keyPoints: [
          'Inversão de fases consolidada: o julgamento das propostas antecede a habilitação como regra geral.',
          'Portal Nacional de Contratações Públicas (PNCP) como sítio oficial obrigatório.',
          'Critérios de Julgamento: menor preço, maior desconto, melhor técnica ou conteúdo artístico, técnica e preço, maior lance, maior retorno econômico.'
        ],
        dryLawArticles: [
          {
            article: 'Art. 74, Lei 14.133/21',
            source: 'Lei de Licitações',
            text: 'É inexigível a licitação quando inviável a competição, em especial nos casos de: I - aquisição de materiais ou equipamentos que só possam ser fornecidos por produtor exclusivo; II - contratação de profissional do setor artístico; III - serviços técnicos especializados de natureza predominantemente intelectual com profissionais de notória especialização...',
            observation: 'Rol de inexigibilidade é meramente exemplificativo!'
          }
        ],
        jurisprudence: [
          {
            tribunal: 'STF',
            number: 'Tema 1.094 (RE 1.133.146)',
            summary: 'É legítima a contratação direta de advogados ou escritórios de advocacia pela Administração Pública por inexigibilidade de licitação, desde que presentes a notória especialização e a singularidade do serviço.',
            relevance: 'Compatibilidade com as prerrogativas da advocacia.'
          }
        ],
        oabTip: 'Atenção aos limites de dispensa de valor: na Lei 14.133/21, valores atualizados anualmente por decreto. Lembre-se: Convite e Tomada de Preço NÃO existem mais!',
        readTime: '18 min'
      }
    ]
  },
  {
    id: 'direito-tributario',
    code: 'CTN/66',
    title: 'Direito Tributário',
    category: 'Direito Público',
    description: 'Sistema Tributário Nacional, princípios constitucionais tributários, imunidades, competência, crédito tributário e lançamento.',
    iconName: 'Receipt',
    totalArticles: 218,
    estimatedHours: '22h de leitura',
    difficulty: 'Intermediário',
    colorGradient: 'from-emerald-500/10 via-teal-500/5 to-transparent',
    accentColor: '#10B981',
    topics: [
      {
        id: 'trib-principios-imunidades',
        title: 'Princípios da Anterioridade e Imunidades Constitucionais',
        summary: 'Regras de não-surpresa tributária, anterioridade anual, nonagesimal e exceções da CF/88.',
        detailedContent: [
          'Princípio da Legalidade Tributária (Art. 150, I, CF): Nenhum tributo pode ser instituído ou majorado sem lei que o estabeleça.',
          'Anterioridade Anual (Art. 150, III, b, CF): O tributo majorado ou criado só pode ser cobrado no exercício financeiro seguinte (1º de janeiro do próximo ano).',
          'Anterioridade Nonagesimal / Noventena (Art. 150, III, c, CF): Exige decorrência mínima de 90 dias entre a data de publicação da lei e a cobrança.',
          'Regra Geral: Aplicação CUMULATIVA de ambas as anterioridades (espera-se o ano seguinte E os 90 dias, o que for maior).',
          'Exceções à Anterioridade: Tributos extrafiscais regulatórios (II, IE, IOF - sem anterioridades); IPI (respeita noventena, dispensa anual); IR (respeita anual, dispensa noventena).'
        ],
        keyPoints: [
          'Imunidade Tributária dos Livros e E-readers (Art. 150, VI, d, CF): Súmula Vinculante 57 estendeu a imunidade aos livros eletrônicos e seus suportes físicos dedicados.',
          'Imunidade Recíproca (Art. 150, VI, a, CF): Impede entes federativos de tributarem patrimônio, renda e serviços uns dos outros. Estendida a empresas públicas prestadoras de serviço público em regime de monopólio (ex: Correios).',
          'Imunidade Religiosa: Abrange templos de qualquer culto e suas organizações assistenciais vinculadas às finalidades essenciais.'
        ],
        dryLawArticles: [
          {
            article: 'Art. 150, III, c, CF/88',
            source: 'Constituição Federal',
            text: 'Sem prejuízo de outras garantias asseguradas ao contribuinte, é vedado à União, aos Estados, ao DF e aos Municípios cobrar tributos antes de decorridos noventa dias da data em que haja sido publicada a lei que os instituiu ou aumentou...',
            observation: 'Garantia fundamental do contribuinte.'
          }
        ],
        jurisprudence: [
          {
            tribunal: 'STF',
            number: 'Súmula Vinculante 57',
            summary: 'A imunidade tributária constante do art. 150, VI, d, da CF/88 aplica-se ao livro eletrônico (e-book) e aos suportes exclusivamente utilizados para fixá-lo, como leitores de livros eletrônicos (e-readers).',
            relevance: 'Interpretação evolutiva do conceito de papel.'
          }
        ],
        oabTip: 'O mnemônico das exceções da noventena: II, IE, IOF e Imposto Extraordinário de Guerra (IEG) podem ser cobrados IMEDIATAMENTE!',
        readTime: '16 min'
      }
    ]
  },
  {
    id: 'direito-processual-civil',
    code: 'CPC/15',
    title: 'Direito Processual Civil',
    category: 'Direito Processual',
    description: 'Normas fundamentais, competência, tutelas provisórias, procedimento comum, provas, sentença e sistema recursal.',
    iconName: 'FileText',
    totalArticles: 1072,
    estimatedHours: '32h de leitura',
    difficulty: 'Intermediário',
    colorGradient: 'from-violet-500/10 via-purple-500/5 to-transparent',
    accentColor: '#7C3AED',
    topics: [
      {
        id: 'proc-tutelas-provisorias',
        title: 'Tutelas de Urgência e Tutelas de Evidência',
        summary: 'Artigos 294 a 311 do CPC/15, requisitos probatórios, tutela cautelar e antecipada e estabilização.',
        detailedContent: [
          'A tutela provisória divide-se em Tutela de Urgência (cautelar ou antecipada) e Tutela de Evidência (Art. 294 CPC).',
          'Tutela de Urgência (Art. 300 CPC): Requisitos cumulativos: probabilidade do direito (fumus boni iuris) e perigo de dano ou risco ao resultado útil do processo (periculum in mora).',
          'Tutela Antecipada: Satisfativa (concede desde logo o próprio bem da vida pretendido). Pode ser requerida em caráter antecedente ou incidental.',
          'Estabilização da Tutela Antecipada Antecedente (Art. 304 CPC): Se deferida a tutela e o réu NÃO interpuser o recurso de agravo de instrumento, a decisão se estabiliza e o processo é extinto sem resolução de mérito. Não faz coisa julgada material, podendo ser revista em ação própria no prazo decadencial de 2 anos.',
          'Tutela de Evidência (Art. 311 CPC): INDEPENDE de demonstração de perigo de dano ou de risco ao resultado útil! Baseia-se na evidência do direito demonstrada documentalmente ou amparada em teses vinculantes.'
        ],
        keyPoints: [
          'Na tutela de evidência NUNCA se exige urgência ou perigo de dano.',
          'A tutela cautelar antecedente NÃO se estabiliza (apenas a antecipada).',
          'A tutela de urgência de natureza antecipada não será concedida quando houver perigo de irreversibilidade dos efeitos da decisão (§ 3º do Art. 300 CPC).'
        ],
        dryLawArticles: [
          {
            article: 'Art. 311, CPC/15',
            source: 'Código de Processo Civil',
            text: 'A tutela da evidência será concedida, independentemente da demonstração de perigo de dano ou de risco ao resultado útil do processo, quando: I - abuso do direito de defesa ou manifesto propósito protelatório; II - alegações de fato puderem ser comprovadas apenas documentalmente e houver tese firmada em julgamento de casos repetitivos ou súmula vinculante...',
            observation: 'Casos dos incisos II e III admitem concessão liminar inaudita altera parte!'
          }
        ],
        jurisprudence: [
          {
            tribunal: 'STJ',
            number: 'Tema Repetitivo 988',
            summary: 'O rol do art. 1.015 do CPC é de taxatividade mitigada, por isso admite a interposição de agravo de instrumento quando verificada a urgência decorrente da inutilidade do julgamento da questão no recurso de apelação.',
            relevance: 'Precedente de máxima relevância prática processual.'
          }
        ],
        oabTip: 'Atenção máxima: o réu que quiser impedir a estabilização da tutela antecipada antecedente DEVE interpor Agravo de Instrumento! Mera contestação nos autos não impede a estabilização, segundo entendimento pacificado do STJ!',
        readTime: '17 min'
      }
    ]
  }
];
