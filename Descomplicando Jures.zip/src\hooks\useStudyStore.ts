import { useState, useEffect } from 'react';

const STORAGE_KEY = 'descomplicando_jures_store_v1';

interface StudyState {
  completedTopics: string[];
  bookmarkedTopics: string[];
  notes: Record<string, string>;
  streakDays: number;
  lastStudyDate: string | null;
  notifiedDecks: string[];
}

export function useStudyStore() {
  const [state, setState] = useState<StudyState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.warn('Failed to load study store from localStorage', e);
    }
    return {
      completedTopics: ['const-direitos-fundamentais'],
      bookmarkedTopics: ['civil-defeitos-negocio'],
      notes: {
        'const-direitos-fundamentais': 'Revisar Tema 280 STF antes da prova de Constitucional!'
      },
      streakDays: 4,
      lastStudyDate: new Date().toISOString().split('T')[0],
      notifiedDecks: []
    };
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      console.warn('Failed to save study store to localStorage', e);
    }
  }, [state]);

  const toggleCompleteTopic = (topicId: string) => {
    setState(prev => {
      const isCompleted = prev.completedTopics.includes(topicId);
      const nextCompleted = isCompleted
        ? prev.completedTopics.filter(id => id !== topicId)
        : [...prev.completedTopics, topicId];
      return { ...prev, completedTopics: nextCompleted };
    });
  };

  const toggleBookmarkTopic = (topicId: string) => {
    setState(prev => {
      const isBookmarked = prev.bookmarkedTopics.includes(topicId);
      const nextBookmarked = isBookmarked
        ? prev.bookmarkedTopics.filter(id => id !== topicId)
        : [...prev.bookmarkedTopics, topicId];
      return { ...prev, bookmarkedTopics: nextBookmarked };
    });
  };

  const updateTopicNote = (topicId: string, note: string) => {
    setState(prev => ({
      ...prev,
      notes: {
        ...prev.notes,
        [topicId]: note
      }
    }));
  };

  const toggleNotifyDeck = (deckTitle: string) => {
    setState(prev => {
      const exists = prev.notifiedDecks.includes(deckTitle);
      const next = exists
        ? prev.notifiedDecks.filter(t => t !== deckTitle)
        : [...prev.notifiedDecks, deckTitle];
      return { ...prev, notifiedDecks: next };
    });
  };

  return {
    completedTopics: state.completedTopics,
    bookmarkedTopics: state.bookmarkedTopics,
    notes: state.notes,
    streakDays: state.streakDays,
    notifiedDecks: state.notifiedDecks,
    toggleCompleteTopic,
    toggleBookmarkTopic,
    updateTopicNote,
    toggleNotifyDeck
  };
}
