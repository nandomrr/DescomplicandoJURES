import type { FlashcardSample, OABQuestionPreview } from '../types';

export const FLASHCARD_PREVIEW_SAMPLES: FlashcardSample[] = [
  {
    id: 'fc-1',
    subject: 'Direito Constitucional',
    deckName: 'Remédios Constitucionais Express',
    front: 'Qual é o prazo decadencial para impetração de Mandado de Segurança?',
    back: '120 dias, contados da ciência, pelo interessado, do ato impugnado (Art. 23 da Lei nº 12.016/2009). É prazo decadencial, não se suspendendo nem se interrompendo!',
    hint: 'Lembre-se: é prazo em dias contínuos e de natureza decadencial.',
    tag: 'Art. 23 Lei 12.016'
  },
  {
    id: 'fc-2',
    subject: 'Direito Penal',
    deckName: 'Teoria da Pena & Hediondos',
    front: 'O homicídio qualificado-privilegiado é considerado crime hediondo?',
    back: 'NÃO! O privilégio (motivo de relevante valor moral/social ou violenta emoção) afasta a hediondez do homicídio, prevalecendo a circunstância subjetiva benéfica.',
    hint: 'Prevalência da natureza subjetiva do privilégio.',
    tag: 'Jurisprudência STJ'
  },
  {
    id: 'fc-3',
    subject: 'Direito Civil',
    deckName: 'Prazos Decadenciais & Prescrição',
    front: 'Qual o termo inicial do prazo decadencial de 4 anos para anular negócio jurídico por COAÇÃO?',
    back: 'Conta-se do dia em que a coação CESSAR (Art. 178, I, do Código Civil), e não da data de celebração do negócio!',
    hint: 'Enquanto persistir a coação, a vítima não possui liberdade para agir.',
    tag: 'Art. 178, I, CC'
  }
];

export const UPCOMING_FLASHCARD_DECKS = [
  {
    title: 'Vade Mecum Lei Seca Express',
    cardsCount: 320,
    discipline: 'Todas as Disciplinas',
    status: 'Em Produção',
    level: 'Essencial OAB'
  },
  {
    title: 'Prazos Processuais CPC/15',
    cardsCount: 140,
    discipline: 'Processo Civil',
    status: 'Em Produção',
    level: 'Prática Forense'
  },
  {
    title: 'Súmulas Vinculantes do STF (1 a 58)',
    cardsCount: 58,
    discipline: 'Constitucional',
    status: 'Em Produção',
    level: 'Alta Incidência'
  },
  {
    title: 'Tipos Penais & Qualificadoras',
    cardsCount: 210,
    discipline: 'Direito Penal',
    status: 'Em Produção',
    level: 'Concursos & OAB'
  }
];

export const OAB_QUESTION_PREVIEW: OABQuestionPreview = {
  id: 'oab-sample-1',
  exam: '40º Exame de Ordem Unificado (FGV)',
  subject: 'Direito Constitucional',
  difficulty: 'Média',
  statement: 'Determinada autoridade policial, munida de denúncia anônima que noticiava a prática de tráfico ilícito de entorpecentes no interior de uma residência, compareceu ao local durante o período noturno e, sem mandado judicial e sem o consentimento do morador, ingressou no imóvel, vindo a apreender substâncias entorpecentes. Diante da sistemática constitucional e da jurisprudência firmada pelo Supremo Tribunal Federal em repercussão geral, assinale a afirmativa correta:',
  legalBasis: 'STF - Tema 280 (RE 603.616) e Art. 5º, XI da CF/88.',
  options: [
    {
      letter: 'A',
      text: 'A entrada forçada foi legítima, uma vez que o crime de tráfico de drogas é permanente, autorizando o flagrante delito e a invasão a qualquer momento, mesmo sem fundadas razões prévias demonstradas.',
      isCorrect: false,
      explanation: 'Incorreta. Conforme o Tema 280 do STF, a natureza permanente do delito não autoriza busca domiciliar desprovida de prévia justa causa fundamentada.'
    },
    {
      letter: 'B',
      text: 'A entrada forçada em domicílio sem mandado judicial é lícita, mesmo no período noturno, quando amparada em fundadas razões, devidamente justificadas pelas circunstâncias do caso que indiquem situação de flagrante delito.',
      isCorrect: true,
      explanation: 'Correta! É a tese literal fixada pelo STF no Tema 280 da repercussão geral (RE 603.616/RO).'
    },
    {
      letter: 'C',
      text: 'O domicílio jamais poderá ser violado durante o período noturno, ainda que haja flagrante delito ou autorização expressa do magistrado competente.',
      isCorrect: false,
      explanation: 'Incorreta. Em caso de flagrante delito, desastre ou socorro, o ingresso é permitido inclusive durante a noite (Art. 5º, XI da CF/88).'
    },
    {
      letter: 'D',
      text: 'A prova obtida é sempre válida quando se confirmar a apreensão da droga no local, convalidando retroativamente a conduta policial, mesmo se originada de mera denúncia anônima sem diligências prévias.',
      isCorrect: false,
      explanation: 'Incorreta. A ilicitude prévia da diligência não se convalida pelo sucesso posterior da apreensão. As provas são ilícitas (Teoria dos Frutos da Árvore Envenenada).'
    }
  ]
};

export const UPCOMING_OAB_SIMULATORS = [
  {
    examName: 'Simulado Geral 1ª Fase OAB',
    questionsCount: 80,
    timeMinutes: 300,
    status: 'Em Andamento',
    badge: 'Preparatório'
  },
  {
    examName: 'Maratona Ética & Estatuto da Advocacia',
    questionsCount: 40,
    timeMinutes: 90,
    status: 'Em Andamento',
    badge: '8 Questões Garantidas'
  },
  {
    examName: 'Constitucional & Direitos Humanos',
    questionsCount: 50,
    timeMinutes: 120,
    status: 'Em Andamento',
    badge: 'Foco FGV'
  },
  {
    examName: 'Simulado Rápido de 15 Minutos (10 Questões)',
    questionsCount: 10,
    timeMinutes: 15,
    status: 'Em Andamento',
    badge: 'Treino Diário'
  }
];
