import confetti from 'canvas-confetti';

export const triggerCompletionConfetti = () => {
  try {
    confetti({
      particleCount: 60,
      spread: 70,
      origin: { y: 0.7 },
      colors: ['#A855F7', '#C084FC', '#6366F1', '#3B82F6', '#10B981']
    });
  } catch (e) {
    console.warn('Confetti could not be triggered', e);
  }
};
