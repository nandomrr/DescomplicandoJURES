import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, CheckCircle2, Bookmark, BookmarkCheck, Volume2, VolumeX, 
  Copy, Check, Sparkles, BookOpen, AlertCircle, Lightbulb, 
  Scale, FileText, PenTool, Type
} from 'lucide-react';
import type { Subject, Topic } from '../types';
import { triggerCompletionConfetti } from '../utils/confetti';

interface StudyReaderModalProps {
  subject: Subject | null;
  topic: Topic | null;
  isOpen: boolean;
  onClose: () => void;
  isCompleted: boolean;
  isBookmarked: boolean;
  onToggleComplete: () => void;
  onToggleBookmark: () => void;
  personalNote: string;
  onSaveNote: (note: string) => void;
}

export const StudyReaderModal: React.FC<StudyReaderModalProps> = ({
  subject,
  topic,
  isOpen,
  onClose,
  isCompleted,
  isBookmarked,
  onToggleComplete,
  onToggleBookmark,
  personalNote,
  onSaveNote
}) => {
  const [fontSize, setFontSize] = useState<'normal' | 'large' | 'xlarge'>('normal');
  const [useSerif, setUseSerif] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [copiedArticle, setCopiedArticle] = useState<string | null>(null);
  const [noteText, setNoteText] = useState(personalNote);
  const [isNoteSaved, setIsNoteSaved] = useState(false);

  // Sync internal note text with prop
  React.useEffect(() => {
    setNoteText(personalNote);
  }, [personalNote]);

  if (!isOpen || !subject || !topic) return null;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedArticle(id);
    setTimeout(() => setCopiedArticle(null), 2000);
  };

  const handleToggleCompleteWithCelebration = () => {
    if (!isCompleted) {
      triggerCompletionConfetti();
    }
    onToggleComplete();
  };

  const handleNoteBlur = () => {
    onSaveNote(noteText);
    setIsNoteSaved(true);
    setTimeout(() => setIsNoteSaved(false), 2000);
  };

  const fontSizeClasses = {
    normal: 'text-sm sm:text-base leading-relaxed',
    large: 'text-base sm:text-lg leading-relaxed',
    xlarge: 'text-lg sm:text-xl leading-relaxed'
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-y-auto bg-black/40 backdrop-blur-md flex justify-end">
        {/* Backdrop dismiss */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0"
        />

        {/* Modal Drawer Container */}
        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 30, stiffness: 300 }}
          className="relative z-10 w-full max-w-4xl bg-white min-h-screen shadow-2xl flex flex-col justify-between border-l border-black/[0.08]"
        >
          {/* Header Controls */}
          <div className="sticky top-0 z-20 bg-white/90 backdrop-blur-md px-6 py-4 border-b border-black/[0.06] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: subject.accentColor }} 
              />
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-500">
                    {subject.code} • {subject.title}
                  </span>
                </div>
                <h3 className="text-sm font-bold text-[#1A1A1A] line-clamp-1">
                  {topic.title}
                </h3>
              </div>
            </div>

            {/* Reading Preferences & Action Buttons */}
            <div className="flex items-center gap-2">
              {/* Audio Study Simulator */}
              <button
                onClick={() => setIsPlayingAudio(!isPlayingAudio)}
                className={`p-2 rounded-full border transition-all cursor-pointer ${
                  isPlayingAudio 
                    ? 'bg-purple-100 border-purple-300 text-purple-700' 
                    : 'bg-neutral-50 border-neutral-200 text-neutral-600 hover:bg-neutral-100'
                }`}
                title={isPlayingAudio ? 'Pausar áudio de foco' : 'Ouvir modo foco (som ambiente)'}
              >
                {isPlayingAudio ? (
                  <div className="flex items-center gap-1.5 px-1">
                    <Volume2 className="w-4 h-4 text-purple-700 animate-pulse" />
                    <span className="text-[11px] font-semibold text-purple-800 hidden sm:inline">Ouvindo</span>
                  </div>
                ) : (
                  <VolumeX className="w-4 h-4" />
                )}
              </button>

              {/* Font Type Toggle (Serif vs Sans) */}
              <button
                onClick={() => setUseSerif(!useSerif)}
                className={`px-2.5 py-1.5 rounded-full border text-xs font-semibold cursor-pointer transition-all ${
                  useSerif ? 'bg-[#1A1A1A] text-white border-[#1A1A1A]' : 'bg-neutral-50 border-neutral-200 text-neutral-700 hover:bg-neutral-100'
                }`}
                title="Alternar entre fonte Sans e Editorial Serif"
              >
                {useSerif ? 'Serif' : 'Sans'}
              </button>

              {/* Font Size Toggle */}
              <button
                onClick={() => {
                  if (fontSize === 'normal') setFontSize('large');
                  else if (fontSize === 'large') setFontSize('xlarge');
                  else setFontSize('normal');
                }}
                className="p-2 rounded-full bg-neutral-50 border border-neutral-200 text-neutral-700 hover:bg-neutral-100 transition-all cursor-pointer"
                title="Ajustar tamanho da fonte"
              >
                <Type className="w-4 h-4" />
              </button>

              {/* Bookmark Toggle */}
              <button
                onClick={onToggleBookmark}
                className={`p-2 rounded-full border transition-all cursor-pointer ${
                  isBookmarked
                    ? 'bg-amber-50 border-amber-300 text-amber-600'
                    : 'bg-neutral-50 border-neutral-200 text-neutral-600 hover:bg-neutral-100'
                }`}
                title={isBookmarked ? 'Remover dos salvos' : 'Salvar para revisar'}
              >
                {isBookmarked ? <BookmarkCheck className="w-4 h-4 fill-amber-500 text-amber-600" /> : <Bookmark className="w-4 h-4" />}
              </button>

              {/* Close Button */}
              <button
                onClick={onClose}
                className="p-2 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-700 transition-all cursor-pointer ml-1"
                aria-label="Fechar"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Reading Content Body */}
          <div className="flex-1 px-6 sm:px-12 py-8 overflow-y-auto">
            {/* Audio Wave Indicator if Active */}
            {isPlayingAudio && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mb-6 p-3 rounded-2xl bg-purple-50/80 border border-purple-200/60 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1">
                    <span className="w-1 h-4 bg-purple-600 rounded-full animate-bounce [animation-delay:0ms]" />
                    <span className="w-1 h-6 bg-purple-600 rounded-full animate-bounce [animation-delay:150ms]" />
                    <span className="w-1 h-3 bg-purple-600 rounded-full animate-bounce [animation-delay:300ms]" />
                    <span className="w-1 h-5 bg-purple-600 rounded-full animate-bounce [animation-delay:450ms]" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-purple-900">Modo Foco Acústico Ativo</h5>
                    <p className="text-[11px] text-purple-700">Frequência sonora para alta retenção jurídica e concentração.</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsPlayingAudio(false)}
                  className="text-xs font-semibold text-purple-800 hover:underline cursor-pointer"
                >
                  Desligar
                </button>
              </motion.div>
            )}

            {/* Topic Main Heading */}
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-neutral-100 text-neutral-600">
                  {topic.readTime} de leitura estimada
                </span>
                <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-purple-50 text-purple-700 border border-purple-200">
                  {subject.category}
                </span>
              </div>
              <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-[#1A1A1A] leading-tight">
                {topic.title}
              </h1>
              <p className="mt-3 text-base text-neutral-600 font-normal leading-relaxed border-l-2 border-purple-500 pl-4 py-0.5">
                {topic.summary}
              </p>
            </div>

            {/* Section 1: Detailed Explanations */}
            <div className={`mb-10 text-neutral-800 space-y-4 ${fontSizeClasses[fontSize]} ${useSerif ? 'font-serif' : 'font-sans'}`}>
              <h2 className="text-lg font-bold text-[#1A1A1A] font-sans flex items-center gap-2 pb-2 border-b border-neutral-100">
                <BookOpen className="w-4 h-4 text-purple-600" />
                Resumo Descomplicado da Doutrina
              </h2>
              {topic.detailedContent.map((paragraph, idx) => (
                <p key={idx} className="leading-relaxed">
                  {paragraph}
                </p>
              ))}
            </div>

            {/* Section 2: Key Points / Mnemonic Insights */}
            <div className="mb-10 p-5 rounded-2xl bg-neutral-50/80 border border-neutral-200/70">
              <h3 className="text-xs font-bold uppercase tracking-wider text-purple-800 mb-3 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                Pontos-Chave & Mnemônicos para Prova
              </h3>
              <ul className="space-y-2">
                {topic.keyPoints.map((point, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-neutral-700">
                    <span className="w-1.5 h-1.5 rounded-full bg-purple-600 mt-2 flex-shrink-0" />
                    <span>{point}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Section 3: Dry Law Articles (Artigos da Lei Seca) */}
            <div className="mb-10">
              <h2 className="text-lg font-bold text-[#1A1A1A] flex items-center gap-2 mb-4 pb-2 border-b border-neutral-100">
                <Scale className="w-4 h-4 text-purple-600" />
                Artigos Fundamentais da Lei Seca
              </h2>
              <div className="space-y-4">
                {topic.dryLawArticles.map((art, idx) => {
                  const isCopied = copiedArticle === `art-${idx}`;
                  return (
                    <div 
                      key={idx}
                      className="p-5 rounded-2xl bg-white border border-neutral-200 shadow-xs relative group hover:border-purple-300 transition-colors"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-purple-900 bg-purple-100/80 px-2.5 py-0.5 rounded-md">
                            {art.article}
                          </span>
                          <span className="text-[11px] text-neutral-400 font-medium">{art.source}</span>
                        </div>
                        <button
                          onClick={() => handleCopy(`${art.article} - ${art.text}`, `art-${idx}`)}
                          className="px-2.5 py-1 rounded-md text-[11px] font-semibold text-neutral-600 hover:text-purple-700 hover:bg-purple-50 flex items-center gap-1 transition-all cursor-pointer"
                          title="Copiar texto do artigo"
                        >
                          {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{isCopied ? 'Copiado!' : 'Copiar'}</span>
                        </button>
                      </div>
                      <blockquote className="text-xs sm:text-sm text-neutral-800 italic leading-relaxed pl-3 border-l-2 border-purple-300">
                        &quot;{art.text}&quot;
                      </blockquote>
                      {art.observation && (
                        <div className="mt-3 text-[11px] text-neutral-500 flex items-start gap-1.5 bg-neutral-50 p-2 rounded-lg">
                          <AlertCircle className="w-3.5 h-3.5 text-purple-600 mt-0.5 flex-shrink-0" />
                          <span><strong>Atenção:</strong> {art.observation}</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Section 4: Jurisprudence STF / STJ */}
            {topic.jurisprudence.length > 0 && (
              <div className="mb-10">
                <h2 className="text-lg font-bold text-[#1A1A1A] flex items-center gap-2 mb-4 pb-2 border-b border-neutral-100">
                  <FileText className="w-4 h-4 text-purple-600" />
                  Jurisprudência & Súmulas Vinculantes
                </h2>
                <div className="space-y-3">
                  {topic.jurisprudence.map((jur, idx) => (
                    <div key={idx} className="p-4 rounded-2xl bg-indigo-50/50 border border-indigo-100">
                      <div className="flex items-center gap-2 mb-1.5">
                        <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-indigo-600 text-white">
                          {jur.tribunal}
                        </span>
                        <span className="text-xs font-bold text-indigo-950">{jur.number}</span>
                      </div>
                      <p className="text-xs sm:text-sm text-neutral-800 font-medium">
                        {jur.summary}
                      </p>
                      <div className="mt-2 text-[11px] text-indigo-700 flex items-center gap-1">
                        <Lightbulb className="w-3 h-3 text-indigo-500" />
                        <span>{jur.relevance}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Section 5: OAB Tip */}
            <div className="mb-10 p-5 rounded-2xl bg-amber-50/60 border border-amber-200/80">
              <h3 className="text-xs font-bold uppercase tracking-wider text-amber-800 mb-2 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                Como a FGV / OAB costuma cobrar este tema:
              </h3>
              <p className="text-xs sm:text-sm text-amber-950 font-medium leading-relaxed">
                {topic.oabTip}
              </p>
            </div>

            {/* Section 6: Personal Notes (Auto-saved) */}
            <div className="mb-10 p-5 rounded-2xl bg-neutral-50 border border-neutral-200">
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold text-neutral-700 flex items-center gap-1.5">
                  <PenTool className="w-3.5 h-3.5 text-neutral-500" />
                  Minhas Anotações de Aula (Salvo automaticamente)
                </label>
                {isNoteSaved && (
                  <span className="text-[10px] font-semibold text-emerald-600 flex items-center gap-1">
                    <Check className="w-3 h-3" /> Salvo!
                  </span>
                )}
              </div>
              <textarea
                value={noteText}
                onChange={(e) => setNoteText(e.target.value)}
                onBlur={handleNoteBlur}
                placeholder="Escreva seus comentários, anotações do professor ou dúvidas para revisar depois..."
                rows={3}
                className="w-full p-3 rounded-xl bg-white border border-neutral-200 text-xs text-neutral-800 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 transition-all"
              />
            </div>
          </div>

          {/* Footer Actions */}
          <div className="sticky bottom-0 bg-white/95 backdrop-blur-md px-6 py-4 border-t border-black/[0.06] flex items-center justify-between">
            <button
              onClick={handleToggleCompleteWithCelebration}
              className={`px-5 py-2.5 rounded-full text-xs font-bold transition-all duration-200 flex items-center gap-2 cursor-pointer ${
                isCompleted
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                  : 'bg-[#1A1A1A] hover:bg-neutral-800 text-white shadow-md active:scale-95'
              }`}
            >
              <CheckCircle2 className={`w-4 h-4 ${isCompleted ? 'text-emerald-600' : 'text-purple-300'}`} />
              <span>{isCompleted ? 'Módulo Concluído ✓' : 'Marcar como Concluído'}</span>
            </button>

            <button
              onClick={onClose}
              className="px-4 py-2 rounded-full text-xs font-semibold text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 transition-colors cursor-pointer"
            >
              Fechar Leitura
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
