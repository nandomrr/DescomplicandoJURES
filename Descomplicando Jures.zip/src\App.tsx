import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Navbar } from './components/Navbar';
import { HeroBento } from './components/HeroBento';
import { SubjectGrid } from './components/SubjectGrid';
import { StudyReaderModal } from './components/StudyReaderModal';
import { FlashcardsSection } from './components/FlashcardsSection';
import { OABSection } from './components/OABSection';
import { VadeMecumModal } from './components/VadeMecumModal';
import { MobileNavigation } from './components/MobileNavigation';
import { Footer } from './components/Footer';
import { SUBJECTS_DATA } from './data/subjectsData';
import { useStudyStore } from './hooks/useStudyStore';
import type { NavigationTab, Subject, Topic } from './types';

export function App() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('conteudo');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isVadeMecumModalOpen, setIsVadeMecumModalOpen] = useState(false);

  // Active Reader State
  const [activeSubject, setActiveSubject] = useState<Subject | null>(null);
  const [activeTopic, setActiveTopic] = useState<Topic | null>(null);
  const [isReaderOpen, setIsReaderOpen] = useState(false);

  // Persistent store
  const {
    completedTopics,
    bookmarkedTopics,
    notes,
    streakDays,
    notifiedDecks,
    toggleCompleteTopic,
    toggleBookmarkTopic,
    updateTopicNote,
    toggleNotifyDeck
  } = useStudyStore();

  // Keyboard shortcut: Ctrl+K / Cmd+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setIsVadeMecumModalOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const totalTopicsCount = SUBJECTS_DATA.reduce((acc, sub) => acc + sub.topics.length, 0);

  const handleSelectTopic = (subject: Subject, topic: Topic) => {
    setActiveSubject(subject);
    setActiveTopic(topic);
    setIsReaderOpen(true);
  };

  const handleScrollToGrid = () => {
    const el = document.getElementById('disciplinas-grid');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    } else {
      setActiveTab('conteudo');
    }
  };

  const handleTabChange = (tab: NavigationTab) => {
    if (tab === 'vademecum') {
      setIsVadeMecumModalOpen(true);
      return;
    }
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#F7F7F5] bg-dot-pattern flex flex-col justify-between selection:bg-purple-200 selection:text-purple-950">
      {/* Background Iridescent Mesh Ambient Overlay */}
      <div className="fixed inset-0 pointer-events-none iridescent-mesh opacity-60 -z-10" />

      {/* Top Floating Pill Navigation */}
      <div className="pt-4">
        <Navbar
          activeTab={activeTab}
          onTabChange={handleTabChange}
          onOpenSearch={() => setIsVadeMecumModalOpen(true)}
          streakDays={streakDays}
          mobileMenuOpen={mobileMenuOpen}
          setMobileMenuOpen={setMobileMenuOpen}
        />
      </div>

      {/* Main View Switching with Motion Transitions */}
      <main className="flex-1">
        <AnimatePresence mode="wait">
          {activeTab === 'conteudo' && (
            <motion.div
              key="tab-conteudo"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              <HeroBento
                completedCount={completedTopics.length}
                totalTopicsCount={totalTopicsCount}
                onExploreClick={handleScrollToGrid}
                onOpenOABTeaser={() => setActiveTab('oab')}
              />

              <SubjectGrid
                subjects={SUBJECTS_DATA}
                completedTopics={completedTopics}
                bookmarkedTopics={bookmarkedTopics}
                onSelectTopic={handleSelectTopic}
              />
            </motion.div>
          )}

          {activeTab === 'flashcards' && (
            <motion.div
              key="tab-flashcards"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              <FlashcardsSection
                notifiedDecks={notifiedDecks}
                onToggleNotify={toggleNotifyDeck}
              />
            </motion.div>
          )}

          {activeTab === 'oab' && (
            <motion.div
              key="tab-oab"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              <OABSection />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Reader Drawer / Modal */}
      <StudyReaderModal
        subject={activeSubject}
        topic={activeTopic}
        isOpen={isReaderOpen}
        onClose={() => setIsReaderOpen(false)}
        isCompleted={activeTopic ? completedTopics.includes(activeTopic.id) : false}
        isBookmarked={activeTopic ? bookmarkedTopics.includes(activeTopic.id) : false}
        onToggleComplete={() => activeTopic && toggleCompleteTopic(activeTopic.id)}
        onToggleBookmark={() => activeTopic && toggleBookmarkTopic(activeTopic.id)}
        personalNote={activeTopic ? notes[activeTopic.id] || '' : ''}
        onSaveNote={(note) => activeTopic && updateTopicNote(activeTopic.id, note)}
      />

      {/* Vade Mecum Instant Search Modal */}
      <VadeMecumModal
        isOpen={isVadeMecumModalOpen}
        onClose={() => setIsVadeMecumModalOpen(false)}
      />

      {/* Mobile Floating Bottom Bar */}
      <MobileNavigation
        activeTab={activeTab}
        onTabChange={handleTabChange}
      />

      {/* Minimal Footer */}
      <Footer
        onTabChange={handleTabChange}
        onOpenVadeMecum={() => setIsVadeMecumModalOpen(true)}
      />
    </div>
  );
}

export default App;
