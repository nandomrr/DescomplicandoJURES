import React from 'react';
import { motion } from 'motion/react';
import { Scale, Search, Sparkles, BookOpen, Layers, Award, Menu, X, Flame, type LucideIcon } from 'lucide-react';
import type { NavigationTab } from '../types';

interface NavbarProps {
  activeTab: NavigationTab;
  onTabChange: (tab: NavigationTab) => void;
  onOpenSearch: () => void;
  streakDays: number;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
}

interface NavTabItem {
  id: NavigationTab;
  label: string;
  icon: LucideIcon;
  badge?: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onTabChange,
  onOpenSearch,
  streakDays,
  mobileMenuOpen,
  setMobileMenuOpen
}) => {
  const tabs: NavTabItem[] = [
    { id: 'conteudo', label: 'Conteúdo Jurídico', icon: BookOpen },
    { id: 'flashcards', label: 'Flashcards', icon: Layers, badge: 'Em Breve' },
    { id: 'oab', label: 'Questões OAB', icon: Award, badge: 'Em Breve' },
    { id: 'vademecum', label: 'Vade Mecum', icon: Scale },
  ];

  return (
    <header className="sticky top-4 z-40 w-full px-4 sm:px-6 max-w-7xl mx-auto">
      <div className="glass-panel rounded-full px-4 sm:px-6 py-2.5 flex items-center justify-between shadow-[0_8px_30px_rgb(0,0,0,0.04)]">
        {/* Brand */}
        <div 
          onClick={() => onTabChange('conteudo')}
          className="flex items-center gap-2.5 cursor-pointer group select-none"
        >
          <div className="w-9 h-9 rounded-full bg-[#1A1A1A] flex items-center justify-center text-white shadow-sm transition-transform duration-300 group-hover:scale-105">
            <Scale className="w-4 h-4 text-purple-300" />
          </div>
          <div className="flex flex-col">
            <span className="font-bold tracking-tight text-sm sm:text-base text-[#1A1A1A] flex items-center gap-1.5">
              Descomplicando <span className="bg-gradient-to-r from-purple-600 to-indigo-600 bg-clip-text text-transparent">Jures</span>
            </span>
            <span className="text-[10px] text-neutral-500 font-medium -mt-1 hidden sm:inline">
              Painel Universitário & OAB
            </span>
          </div>
        </div>

        {/* Desktop Navigation Tabs */}
        <nav className="hidden md:flex items-center gap-1 bg-neutral-100/70 p-1 rounded-full border border-black/[0.04]">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`relative px-4 py-1.5 rounded-full text-xs font-semibold transition-all duration-200 flex items-center gap-1.5 cursor-pointer ${
                  isActive ? 'text-[#1A1A1A]' : 'text-neutral-600 hover:text-neutral-900'
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="nav-pill"
                    className="absolute inset-0 bg-white rounded-full shadow-sm border border-black/[0.04]"
                    transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                  />
                )}
                <span className="relative z-10 flex items-center gap-1.5">
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-purple-600' : 'text-neutral-400'}`} />
                  {tab.label}
                  {tab.badge && (
                    <span className="text-[9px] font-semibold tracking-wider uppercase px-1.5 py-0.5 rounded-full bg-purple-100 text-purple-700 border border-purple-200/60">
                      {tab.badge}
                    </span>
                  )}
                </span>
              </button>
            );
          })}
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-2">
          {/* Streak indicator */}
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-50 border border-amber-200/60 text-amber-800 text-xs font-semibold shadow-xs" title={`${streakDays} dias de ofensiva de estudo!`}>
            <Flame className="w-3.5 h-3.5 text-amber-500 fill-amber-500 animate-pulse" />
            <span>{streakDays}d</span>
          </div>

          {/* Search Trigger */}
          <button
            onClick={onOpenSearch}
            className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-white hover:bg-neutral-50 text-neutral-600 text-xs font-medium border border-black/[0.06] transition-all cursor-pointer shadow-2xs hover:border-black/[0.12]"
            title="Buscar artigos, leis ou matérias (Ctrl+K)"
          >
            <Search className="w-3.5 h-3.5 text-neutral-400" />
            <span className="text-neutral-400">Buscar no Vade Mecum...</span>
            <kbd className="hidden lg:inline text-[10px] bg-neutral-100 text-neutral-500 px-1.5 py-0.5 rounded border border-neutral-200 font-mono">⌘K</kbd>
          </button>

          {/* Quick study CTA */}
          <button
            onClick={() => onTabChange('conteudo')}
            className="px-3.5 sm:px-4 py-1.5 rounded-full bg-[#1A1A1A] hover:bg-neutral-800 text-white text-xs font-semibold shadow-sm transition-all duration-200 flex items-center gap-1.5 cursor-pointer active:scale-95"
          >
            <Sparkles className="w-3 h-3 text-purple-300" />
            <span className="hidden sm:inline">Estudar</span> Agora
          </button>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-full hover:bg-neutral-100 text-neutral-700 cursor-pointer"
            aria-label="Abrir menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Dropdown Menu */}
      {mobileMenuOpen && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className="md:hidden mt-2 p-3 glass-dropdown rounded-2xl shadow-xl flex flex-col gap-1 border border-black/[0.08]"
        >
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  onTabChange(tab.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full px-4 py-2.5 rounded-xl text-left text-sm font-semibold flex items-center justify-between transition-colors ${
                  isActive ? 'bg-purple-50 text-purple-900 border border-purple-200/50' : 'text-neutral-700 hover:bg-neutral-100'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-purple-600' : 'text-neutral-500'}`} />
                  <span>{tab.label}</span>
                </div>
                {tab.badge && (
                  <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full bg-purple-100 text-purple-700">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
          <div className="pt-2 mt-1 border-t border-neutral-100">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenSearch();
              }}
              className="w-full px-4 py-2 rounded-xl text-left text-xs font-medium text-neutral-600 flex items-center gap-2 bg-neutral-50"
            >
              <Search className="w-4 h-4 text-neutral-400" />
              <span>Buscar no Vade Mecum...</span>
            </button>
          </div>
        </motion.div>
      )}
    </header>
  );
};
