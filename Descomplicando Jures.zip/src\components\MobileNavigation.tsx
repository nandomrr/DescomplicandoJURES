import React from 'react';
import { BookOpen, Layers, Award, Scale, type LucideIcon } from 'lucide-react';
import type { NavigationTab } from '../types';

interface MobileNavigationProps {
  activeTab: NavigationTab;
  onTabChange: (tab: NavigationTab) => void;
}

interface MobileTabItem {
  id: NavigationTab;
  label: string;
  icon: LucideIcon;
  badge?: string;
}

export const MobileNavigation: React.FC<MobileNavigationProps> = ({
  activeTab,
  onTabChange
}) => {
  const tabs: MobileTabItem[] = [
    { id: 'conteudo', label: 'Conteúdo', icon: BookOpen },
    { id: 'flashcards', label: 'Flashcards', icon: Layers, badge: 'Breve' },
    { id: 'oab', label: 'OAB', icon: Award, badge: 'Breve' },
    { id: 'vademecum', label: 'Vade Mecum', icon: Scale },
  ];

  return (
    <div className="md:hidden fixed bottom-4 inset-x-4 z-40">
      <div className="glass-panel rounded-full p-1.5 shadow-[0_10px_35px_rgba(0,0,0,0.15)] border border-black/[0.08] flex items-center justify-around bg-white/95 backdrop-blur-xl">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`relative py-2 px-3 rounded-full flex flex-col items-center justify-center transition-all cursor-pointer flex-1 ${
                isActive ? 'text-purple-700 font-bold' : 'text-neutral-500 font-medium'
              }`}
            >
              <div className="relative">
                <Icon className={`w-4 h-4 ${isActive ? 'text-purple-600 scale-110' : 'text-neutral-400'}`} />
                {tab.badge && (
                  <span className="absolute -top-1.5 -right-2 text-[8px] font-bold px-1 rounded-full bg-purple-100 text-purple-700">
                    •
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight truncate max-w-[70px]">
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
