import React from 'react';
import { motion } from 'motion/react';
import { Scale, BookOpen, ShieldAlert, Building2, Receipt, FileText, ArrowRight, CheckCircle2, ChevronRight, Clock, BookMarked } from 'lucide-react';
import type { Subject, Topic } from '../types';

interface SubjectCardProps {
  subject: Subject;
  completedTopics: string[];
  bookmarkedTopics: string[];
  onSelectTopic: (subject: Subject, topic: Topic) => void;
}

export const SubjectCard: React.FC<SubjectCardProps> = ({
  subject,
  completedTopics,
  bookmarkedTopics,
  onSelectTopic
}) => {
  // Icon mapper
  const getIcon = (name: string) => {
    switch (name) {
      case 'Scale': return <Scale className="w-5 h-5" />;
      case 'BookOpen': return <BookOpen className="w-5 h-5" />;
      case 'ShieldAlert': return <ShieldAlert className="w-5 h-5" />;
      case 'Building2': return <Building2 className="w-5 h-5" />;
      case 'Receipt': return <Receipt className="w-5 h-5" />;
      case 'FileText': return <FileText className="w-5 h-5" />;
      default: return <Scale className="w-5 h-5" />;
    }
  };

  const subjectCompletedCount = subject.topics.filter(t => completedTopics.includes(t.id)).length;
  const progressPercent = Math.round((subjectCompletedCount / (subject.topics.length || 1)) * 100);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.98 }}
      className="glass-panel rounded-3xl p-6 flex flex-col justify-between glow-card-hover relative group border border-black/[0.06] bg-white/80"
    >
      <div>
        {/* Top Header of Card */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div 
              className="w-10 h-10 rounded-2xl flex items-center justify-center text-white shadow-xs"
              style={{ backgroundColor: subject.accentColor }}
            >
              {getIcon(subject.iconName)}
            </div>
            <div>
              <span className="text-[10px] font-bold tracking-wider uppercase px-2 py-0.5 rounded-full bg-neutral-100 text-neutral-600 border border-neutral-200">
                {subject.code}
              </span>
              <span className="text-xs text-neutral-400 font-medium ml-2">
                {subject.category}
              </span>
            </div>
          </div>

          <span className="text-[11px] font-semibold text-neutral-500 flex items-center gap-1">
            <Clock className="w-3 h-3 text-neutral-400" />
            {subject.estimatedHours}
          </span>
        </div>

        {/* Title & Description */}
        <h3 className="text-xl font-bold tracking-tight text-[#1A1A1A] group-hover:text-purple-700 transition-colors">
          {subject.title}
        </h3>
        <p className="mt-1.5 text-xs text-neutral-500 line-clamp-2 leading-relaxed">
          {subject.description}
        </p>

        {/* Progress Bar */}
        <div className="mt-4">
          <div className="flex items-center justify-between text-[11px] mb-1.5">
            <span className="text-neutral-500 font-medium">Progresso da Disciplina</span>
            <span className="font-bold text-[#1A1A1A]">{progressPercent}%</span>
          </div>
          <div className="w-full h-1.5 bg-neutral-100 rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{
                width: `${progressPercent}%`,
                backgroundColor: subject.accentColor
              }}
            />
          </div>
        </div>

        {/* Topics List Preview */}
        <div className="mt-5 space-y-1.5 border-t border-black/[0.04] pt-4">
          <div className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 mb-2">
            Módulos de Estudo ({subject.topics.length})
          </div>
          {subject.topics.map((topic) => {
            const isCompleted = completedTopics.includes(topic.id);
            const isBookmarked = bookmarkedTopics.includes(topic.id);

            return (
              <div
                key={topic.id}
                onClick={() => onSelectTopic(subject, topic)}
                className="group/topic flex items-center justify-between p-2 rounded-xl hover:bg-neutral-50 cursor-pointer transition-all border border-transparent hover:border-black/[0.04]"
              >
                <div className="flex items-center gap-2 min-w-0 pr-2">
                  {isCompleted ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  ) : (
                    <div className="w-4 h-4 rounded-full border border-neutral-300 flex-shrink-0 group-hover/topic:border-purple-500 transition-colors" />
                  )}
                  <span className={`text-xs truncate font-medium ${isCompleted ? 'text-neutral-400 line-through' : 'text-neutral-700 group-hover/topic:text-[#1A1A1A]'}`}>
                    {topic.title}
                  </span>
                  {isBookmarked && (
                    <BookMarked className="w-3 h-3 text-amber-500 flex-shrink-0 fill-amber-500" />
                  )}
                </div>

                <div className="flex items-center gap-1.5 flex-shrink-0">
                  <span className="text-[10px] text-neutral-400 font-medium">{topic.readTime}</span>
                  <ChevronRight className="w-3.5 h-3.5 text-neutral-400 group-hover/topic:translate-x-0.5 group-hover/topic:text-purple-600 transition-all" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Action Footer */}
      <div className="mt-6 pt-4 border-t border-black/[0.04] flex items-center justify-between">
        <span className="text-[11px] text-neutral-400 font-medium">
          {subject.totalArticles} artigos mapeados
        </span>
        <button
          onClick={() => onSelectTopic(subject, subject.topics[0])}
          className="px-3.5 py-1.5 rounded-full bg-neutral-100 hover:bg-[#1A1A1A] hover:text-white text-xs font-semibold text-neutral-800 transition-all duration-200 flex items-center gap-1.5 cursor-pointer group-hover:bg-[#1A1A1A] group-hover:text-white active:scale-95"
        >
          Iniciar Leitura <ArrowRight className="w-3 h-3" />
        </button>
      </div>
    </motion.div>
  );
};
